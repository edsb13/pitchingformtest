import fetch from "node-fetch";

async function run() {
  console.log("Fetching sheet data from google API via our backend");
}
run();
