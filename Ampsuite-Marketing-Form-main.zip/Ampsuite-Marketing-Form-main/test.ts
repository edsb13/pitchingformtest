import fs from 'fs';
import FormData from 'form-data';

(async () => {
    try {
        const formData = new FormData();
        const fakeExcel = Buffer.from("");
        formData.append("files", fakeExcel, { filename: "test.xlsx", contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });

        const res = await fetch('http://localhost:3000/api/extract', {
            method: 'POST',
            body: formData as any,
            headers: formData.getHeaders(),
        });
        const text = await res.text();
        console.log("Status:", res.status, "Body:", text);
    } catch(e) {
        console.error("FAIL", e);
    }
})();
