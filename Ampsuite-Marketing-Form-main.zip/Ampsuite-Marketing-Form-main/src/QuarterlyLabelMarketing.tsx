import React, { useState } from 'react';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from "motion/react";

export default function QuarterlyLabelMarketing() {
  const [formData, setFormData] = useState({
    labelName: '',
    reviewPeriod: '',
    priorityArtists: '',
    upcomingReleases: '',
    whatWorkedWell: '',
    whatDidNotWorkWell: '',
    reflectionLastQuarter: '',
    dspActivities: '',
    mainFocusNext3Months: '',
    importantDSPs: [] as string[],
    otherDSP: '',
    marketingActivities: '',
    beatportHype: '',
    biggestChallenge: '',
    additionalComments: '',
    contactEmail: ''
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (dsp: string) => {
    setFormData(prev => {
      const isSelected = prev.importantDSPs.includes(dsp);
      const newDSPs = isSelected 
        ? prev.importantDSPs.filter(d => d !== dsp)
        : [...prev.importantDSPs, dsp];
      return { ...prev, importantDSPs: newDSPs };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      const response = await fetch('/api/quarterly-marketing/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to submit form');
      }

      setStatus('success');
    } catch (error) {
      console.error("Error submitting form:", error);
      setStatus('error'); // We can simply use this or add a basic alert
      alert("There was an issue submitting your form. Please try again.");
      setStatus('idle');
    }
  };

  const renderSuccess = () => (
      <motion.div 
        key="success"
        initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} transition={{ duration: 0.4 }}
        className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12 max-w-[1400px] mx-auto w-full"
      >
        <div className="bg-white p-10 rounded-3xl shadow-xl shadow-slate-200/50 border border-emerald-100 flex flex-col items-center text-center max-w-lg">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Form Submitted</h2>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Thank you for providing your quarterly marketing overview. We have received your submission and will get back to you shortly to book some time.
          </p>
          <button
            onClick={() => {
              setFormData({ 
                labelName: '',
                reviewPeriod: '',
                priorityArtists: '',
                upcomingReleases: '',
                whatWorkedWell: '',
                whatDidNotWorkWell: '',
                reflectionLastQuarter: '',
                dspActivities: '',
                mainFocusNext3Months: '',
                importantDSPs: [],
                otherDSP: '',
                marketingActivities: '', 
                beatportHype: '', 
                biggestChallenge: '', 
                additionalComments: '', 
                contactEmail: '' 
              });
              setStatus('idle');
            }}
            className="px-8 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all"
          >
            Submit Another
          </button>
        </div>
      </motion.div>
  );

  return (
    <AnimatePresence mode="wait">
      {status === 'success' ? (
        renderSuccess()
      ) : (
      <motion.div 
        key="form"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
        className="flex-1 flex flex-col lg:flex-row gap-12 p-6 lg:p-12 max-w-[1400px] mx-auto w-full"
      >
      <div className="w-full lg:w-1/3 flex flex-col lg:sticky lg:top-12 lg:self-start lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto pb-8 no-scrollbar">
        <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
          Quarterly Label Meeting
        </h1>
        <p className="text-lg text-slate-500 leading-relaxed mb-6">
          Please complete this form to provide an overview of your label's marketing performance and upcoming objectives for the next quarter, we will get back to you shortly.
        </p>
        
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mt-4">
          <h3 className="font-bold text-slate-900 text-lg mb-3">How it works:</h3>
          <ul className="space-y-3 text-sm text-slate-600 list-disc list-inside">
            <li>Once submitted, this information is securely logged for us to review.</li>
            <li>Our team will evaluate your submission, identifying key priority artists and focus areas.</li>
            <li>We will use these details to help schedule a quarterly label meeting with yourself, talk through your plans, and help where possible.</li>
          </ul>
        </div>
      </div>
      <div className="w-full lg:w-2/3 flex flex-col justify-center">
        <form onSubmit={handleSubmit} className="bg-purple-50/50 p-8 lg:p-10 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100">
          <div className="space-y-10">
            {/* --- General Information --- */}
            <div className="space-y-6">
              <div className="border-b border-slate-200/60 pb-3 mb-2">
                <h3 className="text-xl font-bold text-slate-800">General Information</h3>
              </div>
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Label Name
                </label>
                <input
                  type="text"
                  name="labelName"
                  value={formData.labelName}
                  onChange={handleInputChange}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Review Period (e.g., Q1 2026)
                </label>
                <input
                  type="text"
                  name="reviewPeriod"
                  value={formData.reviewPeriod}
                  onChange={handleInputChange}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Contact Email *
                </label>
                <input
                  type="email"
                  name="contactEmail"
                  value={formData.contactEmail}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                  placeholder="your@email.com"
                />
              </div>
            </div>

            {/* --- Future Outlook --- */}
            <div className="space-y-6">
              <div className="border-b border-slate-200/60 pb-3 mb-2 mt-4">
                <h3 className="text-xl font-bold text-slate-800">Future Outlook</h3>
                <p className="text-xs text-slate-500 mt-1">Focus and priorities for the upcoming period.</p>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What are the label's main goals or focus areas for the next 3 months?
                </label>
                <textarea
                  name="mainFocusNext3Months"
                  value={formData.mainFocusNext3Months}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Who are your priority artists for the upcoming year?
                </label>
                <input
                  type="text"
                  name="priorityArtists"
                  value={formData.priorityArtists}
                  onChange={handleInputChange}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What are your key upcoming releases and their anticipated dates?
                </label>
                <input
                  type="text"
                  name="upcomingReleases"
                  value={formData.upcomingReleases}
                  onChange={handleInputChange}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What marketing activities do you have planned around your priority artists? *
                </label>
                <textarea
                  name="marketingActivities"
                  value={formData.marketingActivities}
                  onChange={handleInputChange}
                  required
                  rows={4}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                  placeholder="Detail your upcoming marketing activities..."
                />
              </div>
            </div>

            {/* --- Past Reflection --- */}
            <div className="space-y-6">
              <div className="border-b border-slate-200/60 pb-3 mb-2 mt-4">
                <h3 className="text-xl font-bold text-slate-800">Past Reflection</h3>
                <p className="text-xs text-slate-500 mt-1">Reviewing the previous quarter and year.</p>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Looking back at the last quarter, how many releases did you put out, and for which artists?
                </label>
                <textarea
                  name="reflectionLastQuarter"
                  value={formData.reflectionLastQuarter}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What strategies or campaigns worked well during the last period?
                </label>
                <textarea
                  name="whatWorkedWell"
                  value={formData.whatWorkedWell}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What areas didn't perform as well as expected?
                </label>
                <textarea
                  name="whatDidNotWorkWell"
                  value={formData.whatDidNotWorkWell}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>
            </div>

            {/* --- DSP Strategy & Challenges --- */}
            <div className="space-y-6">
              <div className="border-b border-slate-200/60 pb-3 mb-2 mt-4">
                <h3 className="text-xl font-bold text-slate-800">DSP Strategy & Challenges</h3>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Which DSPs are currently most important to your label? (Select all that apply)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                  {['Spotify', 'Apple Music', 'Beatport', 'Amazon Music', 'YouTube Music', 'SoundCloud', 'TikTok / Short-form platforms', 'Other'].map(dsp => (
                    <label key={dsp} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.importantDSPs.includes(dsp)}
                        onChange={() => handleCheckboxChange(dsp)}
                        className="form-checkbox text-[#00AEEF] focus:ring-[#00AEEF] rounded border-slate-300 w-5 h-5 transition-all"
                      />
                      <span className="text-slate-700">{dsp}</span>
                    </label>
                  ))}
                </div>
              </div>

              {formData.importantDSPs.includes('Other') && (
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    If 'Other' DSPs were selected, please specify:
                  </label>
                  <input
                    type="text"
                    name="otherDSP"
                    value={formData.otherDSP}
                    onChange={handleInputChange}
                    className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What active strategies or campaigns are you running on your priority DSPs?
                </label>
                <textarea
                  name="dspActivities"
                  value={formData.dspActivities}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Is your label currently enrolled in Beatport Hype? *
                </label>
                <select
                  name="beatportHype"
                  value={formData.beatportHype}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                >
                  <option value="" disabled>Select an option...</option>
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  What is your biggest challenge or blocker to growth right now? *
                </label>
                <textarea
                  name="biggestChallenge"
                  value={formData.biggestChallenge}
                  onChange={handleInputChange}
                  required
                  rows={4}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                  placeholder="What challenges are you facing..."
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  Do you have any additional comments or information to share?
                </label>
                <textarea
                  name="additionalComments"
                  value={formData.additionalComments}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full bg-white border border-slate-200 text-slate-900 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/50 focus:border-[#00AEEF] transition-all"
                  placeholder="Any other details..."
                />
              </div>
            </div>
          </div>
          
          <div className="mt-8">
            <button
              type="submit"
              disabled={status === 'submitting'}
              className="w-full px-8 py-4 bg-[#00AEEF] text-white rounded-2xl font-bold shadow-lg shadow-[#00AEEF]/20 hover:bg-[#009CE0] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {status === 'submitting' ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  Submitting Form...
                </>
              ) : (
                "Submit"
              )}
            </button>
          </div>
        </form>
      </div>
    </motion.div>
      )}
    </AnimatePresence>
  );
}
