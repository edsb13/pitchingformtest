import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from "motion/react";

export default function ScheduleReminders() {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [parsedEvents, setParsedEvents] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  const [userEmail, setUserEmail] = useState(localStorage.getItem('userEmail') || '');
  const [reminderOptions, setReminderOptions] = useState({
    pitchDeadline: true,
    djChart: true,
  });

  useEffect(() => {
    localStorage.setItem('userEmail', userEmail);
  }, [userEmail]);

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const handleFileSelected = async (selectedFile: File) => {
    setFile(selectedFile);
    setError('');
    setIsProcessing(true);
    setParsedEvents([]);

    const formData = new FormData();
    formData.append('schedule', selectedFile);

    try {
      const response = await fetch('/api/parse-schedule', {
        method: 'POST',
        body: formData,
      });
      
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") === -1) {
        throw new Error("Received an unexpected response from the server.");
      }
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to parse schedule.');
      }
      
      const sortedEvents = (data.events || []).sort((a: any, b: any) => {
        const dateA = a.releaseDate ? new Date(a.releaseDate).getTime() : 0;
        const dateB = b.releaseDate ? new Date(b.releaseDate).getTime() : 0;
        return dateA - dateB;
      });
      setParsedEvents(sortedEvents.map((e: any, idx: number) => ({ ...e, _id: idx, selected: true })));
    } catch (err: any) {
      setError(err.message || 'Error parsing file.');
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleSelection = (id: number) => {
    setParsedEvents(prev => prev.map(ev => ev._id === id ? { ...ev, selected: !ev.selected } : ev));
  };

  const updateEventData = (id: number, field: string, value: string) => {
    setParsedEvents(prev => prev.map(ev => ev._id === id ? { ...ev, [field]: value } : ev));
  };

  const downloadICS = () => {
    const selectedEvents = parsedEvents.filter(e => e.selected);
    if (selectedEvents.length === 0) return;

    let icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Ampsuite//Pitch Reminders//EN",
      "CALSCALE:GREGORIAN",
    ];

    selectedEvents.forEach((ev: any, idx) => {
      // Create a unique UI and properly format dates to YYYYMMDDTHHMMSSZ (UTC)
      
      // We will assume dates are parsed Server-Side and passed down as ISO strings
      const pitchDate = new Date(ev.pitchDeadline);
      const releaseDate = new Date(ev.releaseDate);
      
      const formatICSDate = (d: Date) => {
        return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };

      const makeEvent = (start: Date, summary: string, desc: string, uidPrefix: string) => {
        const end = new Date(start.getTime() + 60 * 60 * 1000);
        icsContent.push(
          "BEGIN:VEVENT",
          `UID:${uidPrefix}-${idx}-${Date.now()}@ampsuite.com`,
          `DTSTAMP:${formatICSDate(new Date())}`,
          `DTSTART:${formatICSDate(start)}`,
          `DTEND:${formatICSDate(end)}`,
          `SUMMARY:${summary}`,
          `DESCRIPTION:${desc}`,
          "BEGIN:VALARM",
          "TRIGGER:-PT15M",
          "ACTION:DISPLAY",
          `DESCRIPTION:${summary}`,
          "END:VALARM",
          "END:VEVENT"
        );
      };

      const djChartUrl = "https://www.beatport.com/charts?srsltid=AfmBOor0Ws3Oy_WvuPkWlvQ488fZZNUGOrRO3XO5yA5wYEZRcwN-n9Aw";
      const djChartInfoUrl = "https://support.beatport.com/hc/en-us/articles/15481489732244-How-do-I-create-a-DJ-Chart-a-Beatport-Streaming-Playlist";

      if (reminderOptions.pitchDeadline) {
        makeEvent(
          pitchDate,
          `Pitch Deadline: ${ev.artist} - ${ev.title}`,
          `Remember to submit DSP pitch for ${ev.artist} - ${ev.title}. Release Date: ${releaseDate.toLocaleDateString()}`,
          "pitch-reminder"
        );
      }

      if (reminderOptions.djChart) {
        makeEvent(
          releaseDate,
          `Beatport DJ Chart: ${ev.artist} - ${ev.title}`,
          `Link to Beatport DJ Chart: ${djChartUrl}\\nHow do I create a DJ Chart? Info link: ${djChartInfoUrl}\\nRelease Date: ${releaseDate.toLocaleDateString()}`,
          "dj-chart-reminder"
        );
      }
    });

    icsContent.push("END:VCALENDAR");

    const blob = new Blob([icsContent.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'ampsuite_pitch_reminders.ics');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const submitLongLead = async () => {
    const selectedEvents = parsedEvents.filter(e => e.selected);
    if (selectedEvents.length === 0) return;

    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/submit-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events: selectedEvents, userEmail }),
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit schedule.');
      }
      
      setSubmissionSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Error submitting schedule.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col lg:flex-row gap-12 p-6 lg:p-12 max-w-[1400px] mx-auto w-full">
      <div className="w-full lg:w-1/3 flex flex-col lg:sticky lg:top-12 lg:self-start lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto pb-8 no-scrollbar">
        <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
          Release Schedule & Reminders
        </h1>
        <p className="text-lg text-slate-500 leading-relaxed mb-6">
          Upload your release schedule below. We want your long lead releases to be able to pitch for better opportunities at Beatport. We can also parse it and generate calendar reminders so you never forget to pitch a release, or submit a Beatport DJ Chart to us.
        </p>
        <div className="mb-6">
          <p className="text-slate-700 font-semibold mb-2">
            Such opportunities at Beatport we can pitch for on a longer lead time are:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-2 text-slate-600">
            <li>
              <div className="relative group inline-flex items-center">
                <a href="https://www.beatportal.com/discover?topic=69141" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">On Our Radar</a>
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 hidden group-hover:block w-80 p-3 bg-slate-800 text-white text-xs font-normal rounded border border-slate-700 shadow-xl z-50 whitespace-normal leading-relaxed pointer-events-none">
                  Our monthly roundup of emerging DJs and producers we can't stop listening to.
                </div>
              </div>
            </li>
            <li>
              <div className="relative group inline-flex items-center">
                <a href="https://r2.vidzflow.com/source/39a4b773-c93b-4092-8917-da40224fc39f.mp4" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">Unpacked</a>
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 hidden group-hover:block w-80 p-3 bg-slate-800 text-white text-xs font-normal rounded border border-slate-700 shadow-xl z-50 whitespace-normal leading-relaxed pointer-events-none">
                  A DJ's music is everything, and their record bag tells the story. Reveal your must-have tracks and backstage insights from events around the world in Unpacked.
                </div>
              </div>
            </li>
            <li>
              <div className="relative group inline-flex items-center">
                <a href="https://r2.vidzflow.com/source/12ccd4a8-3b34-4ac8-9779-86ae1bd9937a.mp4" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">IG Takeover</a>
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 hidden group-hover:block w-80 p-3 bg-slate-800 text-white text-xs font-normal rounded border border-slate-700 shadow-xl z-50 whitespace-normal leading-relaxed pointer-events-none">
                  Spotlight your new music, sets and moments with an Instagram Stories takeover on Beatport.
                </div>
              </div>
            </li>
            <li>
              and <a href="https://greenroom.beatport.com/artists#social-spotlight" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">more.</a>
            </li>
          </ul>

          <h3 className="font-bold text-slate-900 text-lg mb-2 mt-6">Why submit a Beatport DJ Chart?</h3>
          <p className="text-slate-600 leading-relaxed mb-6">
            Submitting a Beatport DJ Chart curated by the artist leads to increased sales and visibility on the site. More sales happen on Beatport DJ Charts then on any other feature on the Beatport site. for more information, check this link <a href="https://support.beatport.com/hc/en-us/articles/15481489732244-How-do-I-create-a-DJ-Chart-a-Beatport-Streaming-Playlist" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">here</a>.
          </p>
        </div>

        <div className="mt-10 p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
          <h4 className="text-emerald-900 font-semibold mb-2">How it works:</h4>
          <ul className="list-disc pl-5 text-emerald-700 text-sm opacity-90 space-y-2">
            <li>You can export your upcoming releases from your Ampsuite Portal and upload them here.</li>
            <li>You can also download a template from below, fill out what you can and upload it below.</li>
            <li>Once parsed, you can download a <code>.ics</code> file. This is a universal calendar format.</li>
            <li><strong>Apple Calendar & Outlook:</strong> Opening the file usually imports the reminders automatically.</li>
            <li><strong>Google Calendar:</strong> You can go to Google Calendar &gt; Settings &gt; Import &amp; Export and upload the file to add all reminders at once.</li>
          </ul>
        </div>
      </div>

      <div className="w-full lg:w-2/3 flex flex-col items-center justify-center">
        <AnimatePresence mode="wait">
        {!parsedEvents.length && !isProcessing && (
          <motion.div
            key="upload"
            initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} transition={{ duration: 0.3 }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="w-full relative group"
          >
            <input
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              title="Upload Schedule"
            />
            <div className="w-full h-80 rounded-3xl border-2 border-dashed border-slate-300 bg-white flex flex-col items-center justify-center text-center transition-all group-hover:border-emerald-400 group-hover:bg-emerald-50/50">
              <div className="w-20 h-20 mb-6 rounded-2xl bg-emerald-100 text-emerald-500 flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                <svg
                  className="w-10 h-10"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">
                Drop Catalog Export
              </h3>
              <p className="text-slate-500 max-w-sm px-6">
                Drag and drop your catalog export (.csv) here to generate your reminders.
              </p>
            </div>
            
            <div className="mt-6 text-center">
              <p className="text-sm text-slate-500 mb-2">Don't have a schedule formatted yet?</p>
              <a 
                href="/api/pitch/schedule-template" 
                download 
                className="inline-flex items-center justify-center px-5 py-2 z-20 relative bg-white border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 hover:text-emerald-600 transition-colors shadow-sm"
              >
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download Template (.csv)
              </a>
            </div>
          </motion.div>
        )}

        {isProcessing && (
          <motion.div key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }} className="w-full h-80 flex flex-col items-center justify-center">
             <div className="w-16 h-16 border-4 border-slate-200 border-t-emerald-500 rounded-full animate-spin mb-4"></div>
             <p className="text-slate-500 font-medium animate-pulse">Generating your reminders...</p>
          </motion.div>
        )}

        {error && (
           <motion.div key="error" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-8 p-4 bg-red-50 text-red-700 border border-red-200 rounded-xl leading-relaxed w-full">
             <strong className="block font-bold mb-1">Error processing schedule:</strong>
             {error}
           </motion.div>
        )}

        {parsedEvents.length > 0 && (
          <motion.div key="success" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.4 }} className="w-full flex flex-col items-center">
             <div className="w-full bg-white border border-slate-200 rounded-3xl p-8 lg:p-12 shadow-xl shadow-slate-200/50 flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center mb-6 shadow-sm">
                  <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-3xl font-black text-slate-900 mb-2">
                  {parsedEvents.filter(e => e.selected).length} Reminders Selected
                </h3>
                <p className="text-slate-500 mb-8 max-w-md">
                  We've successfully generated reminders. You can untick any releases you do not wish to pitch.
                </p>
                <div className="w-full bg-slate-50 rounded-2xl border border-slate-200 p-4 max-h-[400px] overflow-y-auto mb-8 text-left text-sm shadow-inner">
                  {parsedEvents.map((ev, i) => (
                    <div key={i} className={`flex flex-col gap-2 py-4 border-b border-slate-200/50 last:border-0 transition-opacity ${!ev.selected ? 'opacity-40' : 'opacity-100'}`}>
                      <div className="flex items-center gap-4 cursor-pointer" onClick={() => toggleSelection(ev._id)}>
                        <input 
                          type="checkbox" 
                          className="w-5 h-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer pointer-events-none"
                          checked={ev.selected}
                          readOnly
                        />
                        <div className="flex-1 flex flex-col gap-1">
                          <div className="flex justify-between items-center gap-4">
                            <span className="font-semibold text-slate-700 truncate min-w-0" title={`${ev.artist} - ${ev.title} (${ev.catNo || 'No Cat. No'})`}>
                              {ev.artist} - {ev.title} <span className="font-normal text-slate-400 text-xs ml-1">({ev.catNo})</span>
                            </span>
                            <span className={`flex-shrink-0 font-medium px-3 py-1 rounded-full text-xs transition-colors ${ev.selected ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'}`}>
                              Pitch: {new Date(ev.pitchDeadline).toLocaleDateString()}
                            </span>
                          </div>
                          {ev.alternativeDates && ev.alternativeDates.length > 0 && ev.selected && (
                            <div className="mt-2 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                              <label className="text-xs text-amber-600 font-semibold bg-amber-50 px-2 py-1 rounded flex items-center gap-1">
                                <span>Multiple dates found - please select the correct release date:</span>
                                <div className="relative group flex items-center">
                                  <span className="cursor-help font-bold text-amber-500 bg-amber-100 rounded-full w-4 h-4 flex items-center justify-center text-[10px]">(?)</span>
                                  <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 hidden group-hover:block w-72 p-3 bg-slate-800 text-white text-xs font-normal rounded border border-slate-700 shadow-xl z-50 whitespace-normal leading-relaxed text-center pointer-events-none">
                                    Please select the date where this track goes live on any DSPs first. For example, if your release has an exclusive at Beatport for 2 weeks on a separate catalogue number to another that has been uploaded, please pick the Beatport catalogue numbers exclusive date.
                                  </div>
                                </div>
                              </label>
                              <select 
                                value={ev.releaseDate} 
                                onChange={(e) => {
                                  const newReleaseDate = e.target.value;
                                  const newDateObj = new Date(newReleaseDate);
                                  const newPitchDeadline = new Date(newDateObj.getTime() - 4 * 7 * 24 * 60 * 60 * 1000).toISOString();
                                  setParsedEvents(prev => prev.map(p => {
                                    if (p._id === ev._id) {
                                      const allDates = Array.from(new Set([p.originalDate || p.releaseDate, p.releaseDate, ...(p.alternativeDates || [])]));
                                      return { ...p, releaseDate: newReleaseDate, pitchDeadline: newPitchDeadline, alternativeDates: allDates, originalDate: p.originalDate || p.releaseDate };
                                    }
                                    return p;
                                  }));
                                }}
                                className="text-xs p-1.5 rounded border border-amber-300 bg-white focus:ring-1 focus:ring-amber-500 outline-none text-slate-700 cursor-pointer"
                              >
                                {Array.from(new Set([ev.originalDate || ev.releaseDate, ev.releaseDate, ...(ev.alternativeDates || [])])).sort().map(d => (
                                  <option key={d as string} value={d as string}>{new Date(d as string).toLocaleDateString()}</option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                      </div>
                      {ev.selected && (
                        <div className="pl-9 grid grid-cols-1 sm:grid-cols-3 gap-3 mt-1">
                          <input 
                            type="text" 
                            placeholder="Spotify URL" 
                            value={ev.spotifyUrl || ''} 
                            onChange={(e) => updateEventData(ev._id, 'spotifyUrl', e.target.value)}
                            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none w-full placeholder:text-slate-400"
                          />
                          <input 
                            type="text" 
                            placeholder="Instagram URL" 
                            value={ev.instagramUrl || ''} 
                            onChange={(e) => updateEventData(ev._id, 'instagramUrl', e.target.value)}
                            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none w-full placeholder:text-slate-400"
                          />
                          <input 
                            type="text" 
                            placeholder="Listening Link" 
                            value={ev.listeningUrl || ''} 
                            onChange={(e) => updateEventData(ev._id, 'listeningUrl', e.target.value)}
                            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none w-full placeholder:text-slate-400"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Reminder Options */}
                <div className="w-full text-left mb-8 border border-slate-200 rounded-xl p-6 bg-white shadow-sm">
                  <h4 className="font-bold text-slate-800 mb-4 text-base">Select Reminders to Generate:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="flex items-center gap-3 cursor-pointer group p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all">
                      <input type="checkbox" checked={reminderOptions.pitchDeadline} onChange={(e) => setReminderOptions(prev => ({ ...prev, pitchDeadline: e.target.checked }))} className="w-5 h-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer" />
                      <span className="text-slate-700 font-medium group-hover:text-slate-900 transition-colors">Pitch Deadlines</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer group p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all">
                      <input type="checkbox" checked={reminderOptions.djChart} onChange={(e) => setReminderOptions(prev => ({ ...prev, djChart: e.target.checked }))} className="w-5 h-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer" />
                      <span className="text-slate-700 font-medium group-hover:text-slate-900 transition-colors">DJ Charts</span>
                    </label>
                  </div>
                </div>
                
                {!submissionSuccess && (
                  <div className="w-full max-w-lg mx-auto mb-6 flex flex-col items-center">
                    <div className="w-full relative">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 text-left">Contact Email *</label>
                      <input 
                         type="email" 
                         placeholder="you@domain.com" 
                         required
                         value={userEmail}
                         onChange={e => setUserEmail(e.target.value)}
                         className="w-full text-sm p-3.5 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-400 font-medium"
                      />
                    </div>
                  </div>
                )}
                
                {submissionSuccess ? (
                  <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col gap-4 w-full">
                    <div className="w-full bg-emerald-50 text-emerald-700 p-6 rounded-2xl border border-emerald-200 mb-2 font-medium">
                      Successfully confirmed schedule submission!
                    </div>
                    <button 
                      onClick={downloadICS}
                      className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl active:scale-[0.98] transition-all shadow-md text-sm flex justify-center items-center gap-2 w-full sm:w-auto mx-auto"
                    >
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Download Reminders
                    </button>
                  </motion.div>
                ) : (
                  <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
                      <button 
                        onClick={downloadICS}
                        disabled={parsedEvents.filter(e => e.selected).length === 0}
                        className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl active:scale-[0.98] transition-all shadow-md text-sm flex justify-center items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                        Download Reminders
                      </button>
                      <button 
                        onClick={submitLongLead}
                        disabled={parsedEvents.filter(e => e.selected).length === 0 || isSubmitting || !userEmail}
                        className="flex-1 px-6 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl active:scale-[0.98] transition-all shadow-md shadow-emerald-500/20 text-sm flex justify-center items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isSubmitting ? 'Submitting...' : 'Confirm Schedule Submission'}
                      </button>
                  </div>
                )}
                
                <button 
                  onClick={() => { setFile(null); setParsedEvents([]); setSubmissionSuccess(false); }}
                  className="mt-6 text-slate-500 hover:text-slate-700 font-medium text-sm transition-colors"
                >
                  Start Over
                </button>
             </div>
          </motion.div>
        )}
        </AnimatePresence>
      </div>
    </div>
  );
}
