import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import ScheduleReminders from "./ScheduleReminders";
import QuarterlyLabelMarketing from "./QuarterlyLabelMarketing";
import {
  Upload,
  CheckCircle2,
  AlertCircle,
  Loader2,
  HelpCircle,
  UploadCloud,
  Music,
  ChevronDown,
  ChevronUp,
  Sparkles,
  X
} from "lucide-react";

const validateSpotifyCanvas = (
  file: File,
): Promise<{ valid: boolean; errors: string[] }> => {
  return new Promise((resolve) => {
    const errors: string[] = [];
    if (!["image/jpeg", "video/mp4"].includes(file.type)) {
      errors.push("File must be JPEG or MP4");
    }

    if (file.size > 50 * 1024 * 1024) {
      errors.push("File size must be 50MB or less");
    }

    const url = URL.createObjectURL(file);

    if (file.type === "video/mp4") {
      const video = document.createElement("video");
      video.onloadedmetadata = () => {
        if (video.videoHeight < 720)
          errors.push(
            `Height must be at least 720px (is ${video.videoHeight}px)`,
          );

        const ratio = video.videoWidth / video.videoHeight;
        if (Math.abs(ratio - 9 / 16) > 0.05)
          errors.push(
            `Ratio must be 9:16 (is ${(video.videoWidth / video.videoHeight).toFixed(2)})`,
          );

        if (video.duration < 2.9)
          errors.push(
            `Duration must be at least 3 seconds (is ${video.duration.toFixed(1)}s)`,
          );
        if (video.duration > 8.1)
          errors.push(
            `Duration must be at most 8 seconds (is ${video.duration.toFixed(1)}s)`,
          );

        URL.revokeObjectURL(url);
        resolve({ valid: errors.length === 0, errors });
      };
      video.onerror = () => {
        errors.push("Failed to read video file");
        resolve({ valid: false, errors });
      };
      video.src = url;
    } else {
      const img = new Image();
      img.onload = () => {
        if (img.height < 720)
          errors.push(`Height must be at least 720px (is ${img.height}px)`);

        const ratio = img.width / img.height;
        if (Math.abs(ratio - 9 / 16) > 0.05)
          errors.push(
            `Ratio must be 9:16 (is ${(img.width / img.height).toFixed(2)})`,
          );

        URL.revokeObjectURL(url);
        resolve({ valid: errors.length === 0, errors });
      };
      img.onerror = () => {
        errors.push("Failed to read image file");
        resolve({ valid: false, errors });
      };
      img.src = url;
    }
  });
};

const validateSpotifyClip = (
  file: File,
): Promise<{ valid: boolean; errors: string[] }> => {
  return new Promise((resolve) => {
    const errors: string[] = [];
    if (file.type !== "video/mp4") {
      errors.push("File must be MP4");
    }

    if (file.size > 50 * 1024 * 1024) {
      errors.push("File size must be 50MB or less");
    }

    const url = URL.createObjectURL(file);
    const video = document.createElement("video");

    video.onloadedmetadata = () => {
      if (video.videoWidth >= video.videoHeight)
        errors.push("Video must be vertical");
      if (video.duration < 2.9)
        errors.push(
          `Duration must be at least 3 seconds (is ${video.duration.toFixed(1)}s)`,
        );
      if (video.duration > 30.1)
        errors.push(
          `Duration must be at most 30 seconds (is ${video.duration.toFixed(1)}s)`,
        );

      const isMinRes =
        (video.videoWidth >= 720 && video.videoHeight >= 1280) ||
        (video.videoWidth >= 1280 && video.videoHeight >= 720);
      if (!isMinRes)
        errors.push(
          `Min resolution for a vertical video is essentially 720x1280 (is ${video.videoWidth}x${video.videoHeight})`,
        );

      URL.revokeObjectURL(url);
      resolve({ valid: errors.length === 0, errors });
    };
    video.onerror = () => {
      errors.push("Failed to read video file");
      resolve({ valid: false, errors });
    };
    video.src = url;
  });
};

const isValidSpotifyUrl = (url: string) => {
  if (!url) return true;
  return /^(https?:\/\/)?(www\.)?(open\.)?spotify\.com\/.+/i.test(url);
};

const isValidInstagramUrl = (url: string) => {
  if (!url) return true;
  return /^(https?:\/\/)?(www\.)?instagram\.com\/.+/i.test(url);
};

const isValidListeningUrl = (url: string) => {
  if (!url) return true;
  return /^(https?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/i.test(
    url,
  );
};

const validateArtwork = (
  file: File,
): Promise<{ valid: boolean; errors: string[] }> => {
  return new Promise((resolve) => {
    const errors: string[] = [];
    if (!["image/jpeg", "image/png"].includes(file.type)) {
      errors.push("File must be JPEG or PNG");
    }

    if (file.size > 20 * 1024 * 1024) {
      errors.push("File size must be 20MB or less");
    }
    resolve({ valid: errors.length === 0, errors });
  });
};

const PillSelector = ({
  title,
  options,
  selected,
  onChange,
  maxSelection,
  error,
  required,
}: {
  title: string;
  options: string[];
  selected: string[];
  onChange: (val: string[]) => void;
  maxSelection?: number;
  error?: boolean;
  required?: boolean;
}) => {
  return (
    <div className={`mb-4 p-4 rounded-xl border transition-all relative ${error ? "border-red-300 bg-red-50 shadow-[0_0_15px_rgba(239,68,68,0.2)]" : "border-transparent"}`}>
      {required && (
        <input
          type="text"
          value={selected.join(",")}
          onChange={() => {}}
          required
          title="Please make a selection"
          className="absolute opacity-0 pointer-events-none w-10 h-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[-1]"
        />
      )}
      <h4 className={`font-bold mb-3 ${error ? "text-red-800" : "text-slate-800"}`}>{title}</h4>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => {
          const isSelected = selected.includes(opt);
          return (
            <button
              key={opt}
              type="button"
              onClick={() => {
                if (opt === "None of these") {
                  onChange(["None of these"]);
                } else {
                  let newSelection = selected.filter(
                    (s) => s !== "None of these",
                  );
                  if (isSelected) {
                    newSelection = newSelection.filter((s) => s !== opt);
                  } else {
                    if (!maxSelection || newSelection.length < maxSelection) {
                      newSelection.push(opt);
                    }
                  }
                  onChange(newSelection);
                }
              }}
              className={`px-4 py-2 rounded-full border text-sm font-medium transition-colors ${
                isSelected
                  ? "bg-slate-900 text-white border-slate-900"
                  : "bg-white text-slate-700 border-slate-300 hover:border-slate-400"
              }`}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'pitch' | 'schedule' | 'marketing'>('pitch');
  const [files, setFiles] = useState<File[]>([]);
  const [formData, setFormData] = useState(() => {
    try {
      const saved = localStorage.getItem("ampsuite_pitch_draft_form");
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      contactEmail: "",
    };
  });
  const [status, setStatus] = useState<
    "idle" | "submitting" | "success" | "error"
  >("idle");
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [extractedData, setExtractedData] = useState<any>(() => {
    try {
      const saved = localStorage.getItem("ampsuite_pitch_draft_extracted");
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });

  const [expandedDetails, setExpandedDetails] = useState<Set<number>>(new Set());

  const toggleDetails = (index: number) => {
    setExpandedDetails(prev => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  useEffect(() => {
    localStorage.setItem(
      "ampsuite_pitch_draft_form",
      JSON.stringify(formData),
    );
  }, [formData]);

  useEffect(() => {
    if (extractedData) {
      localStorage.setItem(
        "ampsuite_pitch_draft_extracted",
        JSON.stringify(extractedData),
      );
    } else {
      localStorage.removeItem("ampsuite_pitch_draft_extracted");
    }
  }, [extractedData]);
  const [lastSubmittedData, setLastSubmittedData] = useState<any>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractProgress, setExtractProgress] = useState(0);
  const [isExtractedDataCollapsed, setIsExtractedDataCollapsed] =
    useState(false);
  const [showMissingUrlPopup, setShowMissingUrlPopup] = useState(false);
  const [missingInfoTypes, setMissingInfoTypes] = useState({ urls: false });
  const [showUpcPopup, setShowUpcPopup] = useState(false);

  const missingRequirements = React.useMemo(() => {
    let hasMissingListeningUrl = false;
    let hasUnansweredPitch = false;
    let hasMissingSpotifyQuestions = false;
    let hasMissingFocusTrack = false;
    let hasInvalidUrls = false;
    let hasMissingContactEmail = !formData.contactEmail;

    const payload = Array.isArray(extractedData) ? extractedData : (extractedData ? [extractedData] : []);
    
    payload.forEach((p) => {
      const isVariousArtists = String(p.artistName || "").toLowerCase().trim() === "various artists";
      if (!p.listeningUrl) hasMissingListeningUrl = true;
      if (((p.tracks && p.tracks.length > 1) || ["EP", "Album"].includes(p.releaseFormat)) && !p.focusTrack) hasMissingFocusTrack = true;
      if (!isVariousArtists && p.catalogStoreDelivery !== "Download" && !p.pitchToSpotify) hasUnansweredPitch = true;
      if (!isVariousArtists && p.pitchToSpotify === "Yes" && (!p.spotifyMoods || !p.spotifyInstruments || !p.spotifyStyles || !p.spotifyCultures)) hasMissingSpotifyQuestions = true;
      if (
        (p.spotifyUrl && !isValidSpotifyUrl(p.spotifyUrl)) ||
        (p.instagramUrl && !isValidInstagramUrl(p.instagramUrl)) ||
        (p.listeningUrl && !isValidListeningUrl(p.listeningUrl))
      ) hasInvalidUrls = true;
    });

    const isInvalid = hasMissingListeningUrl || hasMissingFocusTrack || hasUnansweredPitch || hasMissingSpotifyQuestions || hasInvalidUrls || hasMissingContactEmail;

    return {
      hasMissingListeningUrl,
      hasMissingFocusTrack,
      hasUnansweredPitch,
      hasMissingSpotifyQuestions,
      hasInvalidUrls,
      hasMissingContactEmail,
      isInvalid
    };
  }, [extractedData, formData.contactEmail]);

  // --- Pitch Lookup State ---
  const [showLookupModal, setShowLookupModal] = useState(false);
  const [lookupQuery, setLookupQuery] = useState("");
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [lookupError, setLookupError] = useState("");

  const [isDraggingLabelCopy, setIsDraggingLabelCopy] = useState(false);
  const [droppedLabelCopyMessage, setDroppedLabelCopyMessage] = useState<string | null>(null);
  const [isDraggingArtwork, setIsDraggingArtwork] = useState<number | null>(null);
  const [isDraggingCanvas, setIsDraggingCanvas] = useState<number | null>(null);
  const [isDraggingClips, setIsDraggingClips] = useState<number | null>(null);

  const handleCanvasUploadFile = async (file: File, index: number) => {
    const result = await validateSpotifyCanvas(file);
    handleExtractedDataChange(index, "canvasValidation", result);
    if (!result.valid) return;

    handleExtractedDataChange(index, "isUploadingCanvas", true);
    try {
      const formDataUpload = new FormData();
      formDataUpload.append("file", file);
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formDataUpload,
      });
      let data: any = {};
      try {
        data = await res.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload file.");
      }
      if (data.url) {
        handleExtractedDataChange(index, "spotifyCanvasUrl", data.url);
      } else if (data.error) {
        handleExtractedDataChange(index, "canvasValidation", {
          valid: false,
          errors: [data.error],
        });
      }
    } catch (e: any) {
      console.error("Upload error:", e);
      let errorMsg = "Upload failed.";
      if (e instanceof Error) errorMsg = e.message;
      else if (typeof e === "string") errorMsg = e;
      handleExtractedDataChange(index, "canvasValidation", {
        valid: false,
        errors: [errorMsg],
      });
    } finally {
      handleExtractedDataChange(index, "isUploadingCanvas", false);
    }
  };

  const handleValidateCanvas = async (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
  ) => {
    if (e.target.files && e.target.files[0]) {
      await handleCanvasUploadFile(e.target.files[0], index);
    }
  };

  const handleDropCanvas = async (
    e: React.DragEvent<HTMLDivElement>,
    index: number,
  ) => {
    e.preventDefault();
    setIsDraggingCanvas(null);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await handleCanvasUploadFile(e.dataTransfer.files[0], index);
    }
  };

  const handleDragOverCanvas = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingCanvas(index);
  };

  const handleDragLeaveCanvas = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingCanvas(null);
  };

  const handleArtworkUploadFile = async (file: File, index: number) => {
    const result = await validateArtwork(file);
    handleExtractedDataChange(index, "artworkValidation", result);
    if (!result.valid) return;

    handleExtractedDataChange(index, "isUploadingArtwork", true);
    try {
      const formDataUpload = new FormData();
      formDataUpload.append("file", file);
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formDataUpload,
      });
      let data: any = {};
      try {
        data = await res.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload file.");
      }
      if (data.url) {
        handleExtractedDataChange(index, "artworkUrl", data.url);
        handleExtractedDataChange(index, "artworkPreview", URL.createObjectURL(file));
      } else if (data.error) {
        handleExtractedDataChange(index, "artworkValidation", {
          valid: false,
          errors: [data.error],
        });
      }
    } catch (e: any) {
      console.error("Upload error:", e);
      let errorMsg = "Upload failed.";
      if (e instanceof Error) errorMsg = e.message;
      else if (typeof e === "string") errorMsg = e;
      handleExtractedDataChange(index, "artworkValidation", {
        valid: false,
        errors: [errorMsg],
      });
    } finally {
      handleExtractedDataChange(index, "isUploadingArtwork", false);
    }
  };

  const handleValidateArtwork = async (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
  ) => {
    if (e.target.files && e.target.files[0]) {
      await handleArtworkUploadFile(e.target.files[0], index);
    }
  };

  const handleDropArtwork = async (
    e: React.DragEvent<HTMLDivElement>,
    index: number,
  ) => {
    e.preventDefault();
    setIsDraggingArtwork(null);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await handleArtworkUploadFile(e.dataTransfer.files[0], index);
    }
  };

  const handleDragOverArtwork = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingArtwork(index);
  };

  const handleDragLeaveArtwork = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingArtwork(null);
  };

  const handleClipsUploadFile = async (file: File, index: number) => {
    const result = await validateSpotifyClip(file);
    handleExtractedDataChange(index, "clipsValidation", result);
    if (!result.valid) return;

    handleExtractedDataChange(index, "isUploadingClips", true);
    try {
      const formDataUpload = new FormData();
      formDataUpload.append("file", file);
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formDataUpload,
      });
      let data: any = {};
      try {
        data = await res.json();
      } catch (err) {
        throw new Error("Server returned an invalid response.");
      }
      if (!res.ok) {
        throw new Error(data.error || "Failed to upload file.");
      }
      if (data.url) {
        handleExtractedDataChange(index, "spotifyClipsUrl", data.url);
      } else if (data.error) {
        handleExtractedDataChange(index, "clipsValidation", {
          valid: false,
          errors: [data.error],
        });
      }
    } catch (e: any) {
      console.error("Upload error:", e);
      let errorMsg = "Upload failed.";
      if (e instanceof Error) errorMsg = e.message;
      else if (typeof e === "string") errorMsg = e;
      handleExtractedDataChange(index, "clipsValidation", {
        valid: false,
        errors: [errorMsg],
      });
    } finally {
      handleExtractedDataChange(index, "isUploadingClips", false);
    }
  };

  const handleValidateClips = async (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
  ) => {
    if (e.target.files && e.target.files[0]) {
      await handleClipsUploadFile(e.target.files[0], index);
    }
  };

  const handleDropClips = async (
    e: React.DragEvent<HTMLDivElement>,
    index: number,
  ) => {
    e.preventDefault();
    setIsDraggingClips(null);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await handleClipsUploadFile(e.dataTransfer.files[0], index);
    }
  };

  const handleDragOverClips = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingClips(index);
  };

  const handleDragLeaveClips = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingClips(null);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  useEffect(() => {
    if (Array.isArray(extractedData) && extractedData.length > 1) {
      const normalize = (s: any) => String(s || "").toLowerCase().trim();
      const needsAttention = extractedData.some((itemA: any, idxA: number) => {
        return extractedData.some((itemB: any, idxB: number) => {
           if (idxA >= idxB) return false;
           // We consider them a duplicate if ANY of these match AND the match string is not empty
           const matchUPC = normalize(itemA.upc).length > 0 && normalize(itemA.upc) === normalize(itemB.upc);
           const matchCat = normalize(itemA.catalogNumber).length > 0 && normalize(itemA.catalogNumber) === normalize(itemB.catalogNumber);
           const matchName = normalize(itemA.releaseName).length > 0 && normalize(itemA.releaseName) === normalize(itemB.releaseName);
           
           if (matchUPC || matchCat || matchName) {
             return !itemA.catalogStoreDelivery || !itemB.catalogStoreDelivery;
           }
           return false;
        });
      });
      if (needsAttention) {
        setShowUpcPopup(true);
      }
    }
  }, [extractedData]);

  const processFiles = async (selectedFiles: File[]) => {
    let hasError = false;
    const validFiles = selectedFiles.filter((f) =>
      f.name.toLowerCase().endsWith(".xlsx"),
    );
    if (validFiles.length !== selectedFiles.length) {
      setErrorMessage(
        "Some files were ignored because only .xlsx files are supported.",
      );
      hasError = true;
      if (validFiles.length === 0) return;
    }
    const newFiles = [...files, ...validFiles];
    setFiles(newFiles);
    if (!hasError) setErrorMessage("");
    setIsExtracting(true);
    setExtractProgress(0);

    const data = new FormData();
    newFiles.forEach((file) => {
      data.append("files", file);
    });

    data.append("userEmail", localStorage.getItem('userEmail') || "");
    setExtractProgress(10);

    try {
      const response = await fetch("/api/extract", {
        method: "POST",
        body: data,
      });

      let result: any = {};
      try {
        result = await response.json();
      } catch (e) {
        throw new Error(
          "Server returned an invalid response. File may be too large or invalid.",
        );
      }

      setExtractProgress(100);

      if (response.ok && result.success) {
        let processedData = result.data;
        if (Array.isArray(processedData)) {
          // Pre-sync marketing fields across same release
          const syncFields = [
            "spotifyUrl",
            "instagramUrl",
            "additionalInfo",
            "biography",
            "spotifyCanvasUrl",
            "spotifyClipsUrl",
            "clipsCheckAccess",
            "listeningUrl",
            "artworkUrl",
            "wantsPressRelease",
            "pressReleaseUrl",
            "focusTrack",
            "isrc",
          ];
          processedData = processedData.map((d: any, i: number, arr: any[]) => {
            const matchUPC = d.upc;
            const matchCat = d.catalogNumber;
            const matchName = d.releaseName;

            // Look for any existing item previously in `extractedData` too?
            // Actually, we're returning newly extracted ones. Let's just sync among them
            // Or better, let's just make sure subsequent identical releases inherit fields from the first one
            let syncedData = { ...d };
            for (let prevIdx = 0; prevIdx < i; prevIdx++) {
              const prev = arr[prevIdx];
              const isSameRelease =
                (matchUPC && prev.upc === matchUPC) ||
                (matchCat && prev.catalogNumber === matchCat) ||
                (matchName &&
                  prev.releaseName === matchName &&
                  matchName.length > 0);

              if (isSameRelease) {
                syncFields.forEach((f) => {
                  if (prev[f]) syncedData[f] = prev[f];
                });
                break; // Synced with first match
              }
            }
            return syncedData;
          });
        }

        setExtractedData((prevData) => {
          if (!prevData) {
            return processedData;
          }
          // Merge existing user input from prevData into the re-extracted full list
          const existingArr = Array.isArray(prevData) ? prevData : [prevData];

          const syncFields = [
            "spotifyUrl",
            "instagramUrl",
            "additionalInfo",
            "biography",
            "spotifyCanvasUrl",
            "spotifyClipsUrl",
            "isUploadingCanvas",
            "isUploadingClips",
            "canvasValidation",
            "clipsValidation",
            "clipsCheckAccess",
            "pitchToSpotify",
            "spotifyMoods",
            "spotifyInstruments",
            "spotifyStyles",
            "spotifyCultures",
            "listeningUrl",
            "artworkUrl",
            "isUploadingArtwork",
            "artworkValidation",
            "wantsPressRelease",
            "pressReleaseUrl",
            "focusTrack",
            "isrc",
          ];

          const nextData = processedData.map((d: any, index: number) => {
            if (index < existingArr.length) {
              return existingArr[index];
            }
            let synced = { ...d };
            const normalize = (s: any) => String(s || "").toLowerCase().trim();
            for (const existing of existingArr) {
              const matchUPC = normalize(synced.upc).length > 0 && normalize(synced.upc) === normalize(existing.upc);
              const matchCat = normalize(synced.catalogNumber).length > 0 && normalize(synced.catalogNumber) === normalize(existing.catalogNumber);
              const matchName = normalize(synced.releaseName).length > 0 && normalize(synced.releaseName) === normalize(existing.releaseName);
              
              if (matchUPC || matchCat || matchName) {
                syncFields.forEach((f) => {
                  if (existing[f] !== undefined && existing[f] !== "") {
                    synced[f] = existing[f];
                  }
                });
                break;
              }
            }
            return synced;
          });

          return nextData;
        });

        // Pre-fill email if present in the first extracted result
        const firstEmail =
          Array.isArray(result.data) && result.data[0]?.contactEmail
            ? result.data[0].contactEmail
            : "";

        setFormData((prev) => ({
          ...prev,
          contactEmail: prev.contactEmail || firstEmail, // Don't wipe if manually entered
        }));
      } else {
        setErrorMessage(result.error || "Failed to extract data from file.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        err.message || "A network error occurred during extraction.",
      );
    } finally {
      setIsExtracting(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
      e.target.value = "";
    }
  };

  const handleExtractedDataChange = (
    index: number,
    field: string,
    value: any,
  ) => {
    setExtractedData((prevData) => {
      if (Array.isArray(prevData)) {
        const newData = [...prevData];
        const updatedItem = { ...newData[index], [field]: value };
        newData[index] = updatedItem;

        // Auto-sync marketing fields across the same release
        const syncFields = [
          "spotifyUrl",
          "instagramUrl",
          "additionalInfo",
          "biography",
          "spotifyCanvasUrl",
          "spotifyClipsUrl",
          "isUploadingCanvas",
          "isUploadingClips",
          "canvasValidation",
          "clipsValidation",
          "clipsCheckAccess",
          "pitchToSpotify",
          "spotifyMoods",
          "spotifyInstruments",
          "spotifyStyles",
          "spotifyCultures",
          "listeningUrl",
          "artworkUrl",
          "isUploadingArtwork",
          "artworkValidation",
          "wantsPressRelease",
          "pressReleaseUrl",
          "focusTrack",
          "isrc",
        ];

        if (syncFields.includes(field)) {
          const matchUPC = updatedItem.upc;
          const matchCat = updatedItem.catalogNumber;
          const matchName = updatedItem.releaseName;

          if (matchUPC || matchCat || matchName) {
            for (let i = 0; i < newData.length; i++) {
              if (i === index) continue;
              const item = newData[i];
              const isSameRelease =
                (matchUPC && item.upc === matchUPC) ||
                (matchCat && item.catalogNumber === matchCat) ||
                (matchName &&
                  item.releaseName === matchName &&
                  matchName.length > 0);

              if (isSameRelease) {
                newData[i] = { ...item, [field]: value };
              }
            }
          }
        }

        return newData;
      } else if (prevData) {
        return { ...prevData, [field]: value };
      }
      return prevData;
    });
  };

  const handleManualEntryAdd = () => {
    const newEntry = {
      artistName: "",
      releaseName: "",
      labelName: "",
      genre: "",
      releaseFormat: "Single",
      upc: "",
      catalogNumber: "",
      releaseDate: "",
      exclusiveReleaseDate: "",
      exclusiveStore: "",
      preorderDate: "",
      biography: "",
      contactEmail: "",
      spotifyUrl: "",
      instagramUrl: "",
      additionalInfo: "",
      listeningUrl: "",
      artworkUrl: "",
      wantsPressRelease: "",
      pressReleaseUrl: "",
      spotifyCanvasUrl: "",
      spotifyClipsUrl: "",
      clipsCheckAccess: false,
      pitchToSpotify: "",
      spotifyMoods: "",
      spotifyInstruments: "",
      spotifyStyles: "",
      spotifyCultures: "",
    };
    if (Array.isArray(extractedData)) {
      setExpandedDetails(prev => new Set([...prev, extractedData.length]));
      setExtractedData([...extractedData, newEntry]);
    } else if (extractedData) {
      setExpandedDetails(prev => new Set([...Array.from(prev), 1]));
      setExtractedData([extractedData, newEntry]);
    } else {
      setExpandedDetails(new Set([0]));
      setExtractedData([newEntry]);
    }
  };

  const handleManualEntryRemove = (indexToRemove: number) => {
    if (Array.isArray(extractedData)) {
      if (extractedData.length === 1) {
        setExtractedData(null);
      } else {
        setExtractedData(
          extractedData.filter((_, index) => index !== indexToRemove),
        );
      }
    } else {
      setExtractedData(null);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingLabelCopy(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingLabelCopy(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingLabelCopy(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files) as File[];
      processFiles(droppedFiles);
      setDroppedLabelCopyMessage(`Successfully loaded ${droppedFiles.length} file${droppedFiles.length !== 1 ? 's' : ''}`);
      setTimeout(() => setDroppedLabelCopyMessage(null), 3000);
    }
  };

  const performLookup = async (query: string) => {
    if (!query.trim()) return;
    
    setIsLookingUp(true);
    setLookupError("");
    setShowLookupModal(true); // Ensure modal is visible during lookup process
    
    try {
      const resp = await fetch(`/api/pitch/lookup?query=${encodeURIComponent(query)}`);
      const data = await resp.json();
      
      if (!resp.ok) {
        throw new Error(data.error || "Lookup failed.");
      }
      
      const foundItems = data.data || [];
      if (foundItems.length > 0) {
        setExtractedData(foundItems);
        // Pre-fill formData if available in first item
        const first = foundItems[0];
        setFiles([]);
        setFormData(prev => ({
            ...prev,
            contactEmail: first.contactEmail || prev.contactEmail || "",
        }));
        setShowLookupModal(false);
        setLookupQuery("");
        setLastSubmittedData(null);
      } else {
        setLookupError("No releases found.");
      }
    } catch (err: any) {
      setLookupError(err.message || "Something went wrong fetching the pitch.");
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleLookupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await performLookup(lookupQuery);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const lookupParam = params.get("lookup");
    if (lookupParam) {
      setLookupQuery(lookupParam);
      performLookup(lookupParam);
      // Clean up URL to prevent loops on refresh
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const handleSubmit = async (
    e?: React.FormEvent,
    ignoreMissingUrls = false,
  ) => {
    if (e) e.preventDefault();
    setHasAttemptedSubmit(true);
    if (status === "submitting") return;
    setStatus("submitting");
    setErrorMessage("");

    const processPayloadItem = (data: any) => {
      const merged = { ...data, ...formData };

      // Remove Spotify fields if delivery is Download or artist is Various Artists
      const isVariousArtists = String(merged.artistName || "").toLowerCase().trim() === "various artists";
      if (merged.catalogStoreDelivery === "Download" || isVariousArtists) {
        delete merged.pitchToSpotify;
        delete merged.spotifyMoods;
        delete merged.spotifyInstruments;
        delete merged.spotifyStyles;
        delete merged.spotifyCultures;
        delete merged.spotifyCanvasUrl;
        delete merged.spotifyClipsUrl;
        delete merged.clipsCheckAccess;
        if (merged.catalogStoreDelivery === "Download") {
           delete merged.spotifyUrl;
        }
      }
      return merged;
    };

    const payload = Array.isArray(extractedData)
      ? extractedData.map(processPayloadItem)
      : processPayloadItem(extractedData || {});

    const hasMissingListeningUrl = Array.isArray(payload)
      ? payload.some((p) => !p.listeningUrl)
      : !payload.listeningUrl;

    const hasMissingBasicInfo = Array.isArray(payload)
      ? payload.some((p) => !p.artistName || !p.releaseName)
      : !payload.artistName || !payload.releaseName;

    if (hasMissingBasicInfo) {
      setStatus("error");
      setErrorMessage("Please provide Artist Name and Release Name for all releases.");
      return;
    }

    if (hasMissingListeningUrl) {
      setStatus("error");
      setErrorMessage("Please provide a Listening Link URL before submitting.");
      return;
    }

    const hasUnansweredPitch = Array.isArray(payload)
      ? payload.some((p) => {
          const isVariousArtists = String(p.artistName || "").toLowerCase().trim() === "various artists";
          return !isVariousArtists && p.catalogStoreDelivery !== "Download" && !p.pitchToSpotify;
        })
      : (() => {
          const isVariousArtists = String(payload.artistName || "").toLowerCase().trim() === "various artists";
          return !isVariousArtists && payload.catalogStoreDelivery !== "Download" && !payload.pitchToSpotify;
        })();

    if (hasUnansweredPitch) {
      setStatus("error");
      setErrorMessage("Please answer 'Are We Pitching To Spotify?' before submitting.");
      return;
    }

    const hasMissingSpotifyQuestions = Array.isArray(payload)
      ? payload.some((p) => {
          const isVariousArtists = String(p.artistName || "").toLowerCase().trim() === "various artists";
          return !isVariousArtists && p.pitchToSpotify === "Yes" && (!p.spotifyMoods || !p.spotifyInstruments || !p.spotifyStyles || !p.spotifyCultures);
        })
      : (() => {
          const isVariousArtists = String(payload.artistName || "").toLowerCase().trim() === "various artists";
          return !isVariousArtists && payload.pitchToSpotify === "Yes" && (!payload.spotifyMoods || !payload.spotifyInstruments || !payload.spotifyStyles || !payload.spotifyCultures);
        })();

    if (hasMissingSpotifyQuestions) {
      setStatus("error");
      setErrorMessage("Please answer all Spotify questions (Moods, Instruments, Styles, Cultures) for your Spotify pitch before submitting.");
      return;
    }

    const hasMissingFocusTrack = Array.isArray(payload)
      ? payload.some((p) => (p.tracks && p.tracks.length > 1) && !p.focusTrack)
      : (payload.tracks && payload.tracks.length > 1) && !payload.focusTrack;

    if (hasMissingFocusTrack) {
      setStatus("error");
      setErrorMessage("Please select or enter a Focus Track for your releases.");
      return;
    }

    if (!ignoreMissingUrls) {
      const hasMissingUrl = Array.isArray(payload)
        ? payload.some((p) => {
            const needsSpotify = p.catalogStoreDelivery !== "Download";
            return (needsSpotify && !p.spotifyUrl) || !p.instagramUrl;
          })
        : (payload.catalogStoreDelivery !== "Download" &&
            !payload.spotifyUrl) ||
          !payload.instagramUrl;

      if (hasMissingUrl) {
        setStatus("idle");
        setMissingInfoTypes({ urls: hasMissingUrl });
        setShowMissingUrlPopup(true);
        return;
      }
    }

    const hasInvalidFormat = Array.isArray(payload)
      ? payload.some(
          (p) =>
            (p.spotifyUrl && !isValidSpotifyUrl(p.spotifyUrl)) ||
            (p.instagramUrl && !isValidInstagramUrl(p.instagramUrl)) ||
            (p.listeningUrl && !isValidListeningUrl(p.listeningUrl)),
        )
      : (payload.spotifyUrl && !isValidSpotifyUrl(payload.spotifyUrl)) ||
        (payload.instagramUrl && !isValidInstagramUrl(payload.instagramUrl)) ||
        (payload.listeningUrl && !isValidListeningUrl(payload.listeningUrl));

    if (hasInvalidFormat) {
      setStatus("error");
      setErrorMessage("Please fix the invalid URLs before submitting.");
      return;
    }

    try {
      const response = await fetch("/api/pitch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      let result: any = {};
      try {
        result = await response.json();
      } catch (e) {
        throw new Error(
          "Server returned an invalid response. Please try again.",
        );
      }

      if (response.ok && result.success) {
        setLastSubmittedData(payload);
        setStatus("success");

        // Reset form
        setFiles([]);
        setExtractedData(null);
        setFormData({
          contactEmail: "",
        });
        localStorage.removeItem("ampsuite_pitch_draft_form");
        localStorage.removeItem("ampsuite_pitch_draft_extracted");
      } else {
        setStatus("error");
        setErrorMessage(result.error || "Failed to submit form.");
      }
    } catch (err: any) {
      console.error(err);
      setStatus("error");
      setErrorMessage(err.message || "A network error occurred.");
    }
  };

  const handleClearAll = () => {
    setFiles([]);
    setExtractedData(null);
    setFormData({
      contactEmail: "",
    });
    setHasAttemptedSubmit(false);
    setStatus("idle");
    setErrorMessage("");
    localStorage.removeItem("ampsuite_pitch_draft_form");
    localStorage.removeItem("ampsuite_pitch_draft_extracted");
  };

  const renderSuccess = () => {
    let uniqueReleaseCount = 1;
    if (Array.isArray(lastSubmittedData)) {
      const groups: any[] = [];
      lastSubmittedData.forEach((data) => {
        const existingGroup = groups.find(
          (prev) =>
            (data.upc && prev.upc === data.upc) ||
            (data.releaseName &&
              prev.releaseName === data.releaseName &&
              data.releaseName.length > 0)
        );
        if (!existingGroup) {
          groups.push({
            upc: data.upc,
            releaseName: data.releaseName,
          });
        }
      });
      uniqueReleaseCount = groups.length;
    }

    return (
      <motion.div 
        key="success"
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="bg-slate-50 min-h-screen flex items-center justify-center font-sans p-6 print:bg-white print:p-0 print:block"
      >
          <div className="bg-white rounded-xl p-8 md:p-12 shadow-xl shadow-slate-200/50 max-w-2xl w-full border border-slate-100 text-left print:max-w-none print:shadow-none print:border-none print:p-0">
            <div className="print:hidden">
              <p className="text-slate-800 mb-8 text-lg">
                Thank you for submitting your DSP {uniqueReleaseCount > 1 ? "pitches" : "pitch"} for the upcoming {uniqueReleaseCount > 1 ? "releases" : "release"}.
              </p>

              {(() => {
              if (Array.isArray(lastSubmittedData)) {
                const groups: any[] = [];
                lastSubmittedData.forEach((data) => {
                  const existingGroup = groups.find(
                    (prev) =>
                      (data.upc && prev.upc === data.upc) ||
                      (data.releaseName &&
                        prev.releaseName === data.releaseName &&
                        data.releaseName.length > 0)
                  );
                  if (existingGroup) {
                    if (
                      data.catalogNumber &&
                      !existingGroup.catalogNumbers.includes(data.catalogNumber)
                    ) {
                      existingGroup.catalogNumbers.push(data.catalogNumber);
                    }
                  } else {
                    groups.push({
                      artistName: data.artistName,
                      releaseName: data.releaseName,
                      upc: data.upc,
                      catalogNumbers: data.catalogNumber
                        ? [data.catalogNumber]
                        : [],
                    });
                  }
                });

                return (
                  <ul className="list-disc list-outside text-slate-800 mb-8 space-y-2 ml-6 text-lg">
                    {groups.map((g, idx) => (
                      <li key={idx}>
                        <strong>Release:</strong> {g.artistName || "Unknown"} -{" "}
                        {g.releaseName || "Unknown"}
                        {g.catalogNumbers.length > 0
                          ? ` (${g.catalogNumbers.join(", ")})`
                          : ""}
                      </li>
                    ))}
                  </ul>
                );
              } else {
                return (
                  <ul className="list-disc list-outside text-slate-800 mb-8 space-y-2 ml-6 text-lg">
                    <li>
                      <strong>Release:</strong>{" "}
                      {lastSubmittedData?.artistName || "Unknown"} -{" "}
                      {lastSubmittedData?.releaseName || "Unknown"}
                      {lastSubmittedData?.catalogNumber
                        ? ` (${lastSubmittedData.catalogNumber})`
                        : ""}
                    </li>
                  </ul>
                );
              }
            })()}

            <div className="bg-sky-50 border border-sky-100 rounded-2xl p-6 md:p-8 mb-8 text-slate-800 text-base">
              <h3 className="text-xl font-bold text-slate-900 mb-6">
                What you can do next
              </h3>

              <h4 className="font-bold text-slate-900 mb-2">
                Profile Health Check
              </h4>
              <p className="mb-4 text-slate-700">
                Check the artists profile on relevant DSPs are as up to date as
                possible. DSP's and the audience on there are more likely to pay
                attention to a well looked after profile then one that is not.
              </p>
              <p className="mb-2 text-slate-700">
                For Beatport, log into your profile using this <a href="https://greenroom-app.beatport.com/landing" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">link</a>.
              </p>
              <p className="mb-2 text-slate-700">
                For Spotify, log into your profile using this <a href="https://artists.spotify.com/home" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline">link</a>.
              </p>
              <p className="mb-8 text-slate-700">
                For other DSPs, please reach out to <a href="mailto:marketing@ampsuite.com" className="text-sky-600 hover:text-sky-800 underline">marketing@ampsuite.com</a>.
              </p>

              <h4 className="font-bold text-slate-900 mb-2">Beatport</h4>
              <p className="mb-3 text-slate-700">
                An{" "}
                <a
                  href="https://support.beatport.com/hc/en-us/articles/15481489732244-How-do-I-create-a-DJ-Chart-a-Beatport-Streaming-Playlist"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Artist Chart
                </a>{" "}
                helps build pre-orders and sales before, during and after
                release date.
              </p>
              <p className="mb-3 text-slate-700">
                <a
                  href="https://greenroom.beatport.com/labels/hype"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Hype
                </a>{" "}
                tracks are automatically sent to Beatport curators, who select
                tracks for prime feature space on Beatport's home and genre
                pages. Sales and traffic for Hype labels significantly increase
                (on average, <strong>+40% More sales +84% More exposure</strong>
                ).
              </p>
              <p className="mb-6 text-slate-700">
                <a
                  href="https://greenroom.beatport.com/hype/webinar"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Watch this free webinar
                </a>{" "}
                to help you understand the various ways to promote your music on
                Beatport.
              </p>

              <h4 className="font-bold text-slate-900 mb-2">LabelRadar</h4>
              <p className="mb-3 text-slate-700">
                Plan a Remix Contest to unlock global creativity around your release, turning your track into a discovery engine that drives buzz and engagement at scale. This can provide deeper audience engagement and extending the lifespan of your track.
              </p>
              <p className="mb-3 text-slate-700">
                Past partners include Alesso, Armin van Buuren, David Guetta, Deadmau5, Tiësto, Madonna, Kylie Minogue, Benny Benassi, Oliver Heldens, and many more.
              </p>
              <p className="mb-6 text-slate-700">
                <a
                  href="https://www.labelradar.com/sign-up?tab=labels"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline block mb-6"
                >
                  Sign up to LabelRadar here
                </a>
              </p>

              <h4 className="font-bold text-slate-900 mb-2">Beatport Tickets</h4>
              <p className="mb-3 text-slate-700">
                Create an account and add your labels live events{" "}
                <a
                  href="https://greenroom.beatport.com/tickets"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  here
                </a>
              </p>
              <p className="mb-3 text-slate-700">
                Live events help boost online activity around you release, building real bonds and cutting through digital clutter. Incorporate them with your release dates and pre-order dates.
              </p>
              <p className="mb-6 text-slate-700">
                Get the opportunity to seen by the Beatport community through playlists, newsletters and{" "}
                <a
                  href="https://www.beatportal.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Beatportal
                </a>{" "}
                editorial features.
              </p>

              <h4 className="font-bold text-slate-900 mb-2">Spotify</h4>
              <p className="mb-3 text-slate-700">
                A{" "}
                <a
                  href="https://artists.spotify.com/display-campaigns"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Marquee
                </a>{" "}
                helps maximise engagement with new music by guiding listeners to
                dive deeper during the release window.
              </p>
              <p className="mb-3 text-slate-700">
                A{" "}
                <a
                  href="https://artists.spotify.com/display-campaigns"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Showcase
                </a>{" "}
                keeps momentum going for your release by attracting new
                listeners after the initial hype settles.
              </p>
              <p className="text-slate-700">
                Focus on the{" "}
                <a
                  href="https://artists.spotify.com/blog/super-listeners-your-guide-for-developing-fans-who-go-deeper"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-600 hover:text-sky-800 underline"
                >
                  Super Fans
                </a>
                , who average, they make up just 2% of an artist's monthly
                listeners but drive over 18% of monthly streams, account for 50%
                of an artist's ticket sales from Spotify, and are 9x more likely
                to share music with their network than other listeners.
              </p>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-8 mt-4 text-center print:hidden">
            <button
              onClick={() => setStatus("idle")}
              className="text-sky-600 font-semibold hover:text-sky-800 hover:underline transition-all"
            >
              Start New Pitch
            </button>
          </div>
        </div>
      </motion.div>
    );
  };

  const spotifyUrlOptions = Array.isArray(extractedData)
    ? Array.from(
        new Set(extractedData.map((d) => d.spotifyUrl).filter(Boolean)),
      )
    : [];

  const instagramUrlOptions = Array.isArray(extractedData)
    ? Array.from(
        new Set(extractedData.map((d) => d.instagramUrl).filter(Boolean)),
      )
    : [];

  return (
    <>
    <AnimatePresence mode="wait">
      {status === "success" ? (
        renderSuccess()
      ) : (
      <motion.div 
        key="main-app"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-slate-50 min-h-screen flex flex-col font-sans"
      >
      <datalist id="spotifyUrls">
        {spotifyUrlOptions.map((url, i) => (
          <option key={`spotify-${i}`} value={url} />
        ))}
      </datalist>
      <datalist id="instagramUrls">
        {instagramUrlOptions.map((url, i) => (
          <option key={`ig-${i}`} value={url} />
        ))}
      </datalist>

      {/* Lookup Popup */}
      {showLookupModal && (
        <div className="fixed inset-0 bg-slate-900/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg p-6 lg:p-8 relative">
            <button
              onClick={() => setShowLookupModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <h3 className="text-xl font-bold text-slate-900 mb-2 font-sans">
              Update Existing Pitch
            </h3>
            <p className="text-sm text-slate-500 mb-6">
              Enter your UPC or Catalogue Number to retrieve your previously submitted pitch.
            </p>
            <form onSubmit={handleLookupSubmit}>
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="e.g. 19283746532 or AMP001"
                  value={lookupQuery}
                  onChange={(e) => setLookupQuery(e.target.value)}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:border-sky-400 focus:ring-1 focus:ring-sky-100 outline-none transition-all"
                  required
                />
              </div>
              {lookupError && (
                <p className="text-red-500 text-sm mb-4 font-medium">{lookupError}</p>
              )}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowLookupModal(false)}
                  className="px-5 py-2.5 text-slate-600 font-medium hover:bg-slate-50 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLookingUp}
                  className="px-6 py-2.5 bg-[#00AEEF] hover:bg-[#009X] text-white font-bold rounded-xl active:scale-[0.98] transition-all disabled:opacity-50"
                >
                  {isLookingUp ? "Searching..." : "Retrieve Pitch"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* UPC Popup */}
      {showUpcPopup &&
        Array.isArray(extractedData) &&
        extractedData.length > 1 && (
          <div className="fixed inset-0 bg-slate-900/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg p-6 lg:p-8">
              <h3 className="text-xl font-bold text-slate-900 mb-6 font-sans">
                Which Catalogue No. is being delivered to where?
              </h3>
              <div className="space-y-4">
                {extractedData.map((data: any, index: number) => {
                  const normalize = (s: any) => String(s || "").toLowerCase().trim();
                  
                  const isDuplicate = extractedData.some((d: any, i: number) => {
                    if (i === index) return false;
                    const matchUPC = normalize(data.upc).length > 0 && normalize(data.upc) === normalize(d.upc);
                    const matchCat = normalize(data.catalogNumber).length > 0 && normalize(data.catalogNumber) === normalize(d.catalogNumber);
                    const matchName = normalize(data.releaseName).length > 0 && normalize(data.releaseName) === normalize(d.releaseName);
                    return matchUPC || matchCat || matchName;
                  });

                  if (!isDuplicate) return null;
                  
                  return (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all font-sans"
                    >
                    <span className="font-bold text-slate-700">
                      {data.catalogNumber || `Release ${index + 1}`}
                    </span>
                    <select
                      value={data.catalogStoreDelivery || ""}
                      onChange={(e) =>
                        handleExtractedDataChange(
                          index,
                          "catalogStoreDelivery",
                          e.target.value,
                        )
                      }
                      className="ml-4 px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00AEEF] text-sm text-slate-700"
                    >
                      <option value="">Select...</option>
                      <option value="Streaming" disabled={extractedData.some((d: any, i: number) => {
                        if (i === index) return false;
                        const normalize = (s: any) => String(s || "").toLowerCase().trim();
                        const matchUPC = normalize(data.upc).length > 0 && normalize(data.upc) === normalize(d.upc);
                        const matchCat = normalize(data.catalogNumber).length > 0 && normalize(data.catalogNumber) === normalize(d.catalogNumber);
                        const matchName = normalize(data.releaseName).length > 0 && normalize(data.releaseName) === normalize(d.releaseName);
                        const isSameRelease = matchUPC || matchCat || matchName;
                        return isSameRelease && d.catalogStoreDelivery === "Streaming";
                      })}>Streaming</option>
                      <option value="Download" disabled={extractedData.some((d: any, i: number) => {
                        if (i === index) return false;
                        const normalize = (s: any) => String(s || "").toLowerCase().trim();
                        const matchUPC = normalize(data.upc).length > 0 && normalize(data.upc) === normalize(d.upc);
                        const matchCat = normalize(data.catalogNumber).length > 0 && normalize(data.catalogNumber) === normalize(d.catalogNumber);
                        const matchName = normalize(data.releaseName).length > 0 && normalize(data.releaseName) === normalize(d.releaseName);
                        const isSameRelease = matchUPC || matchCat || matchName;
                        return isSameRelease && d.catalogStoreDelivery === "Download";
                      })}>Download</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  );
                })}
              </div>
              <div className="mt-8 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    const allSelected = extractedData.every(
                      (d: any, idx: number) => {
                        const normalize = (s: any) => String(s || "").toLowerCase().trim();
                        const isDuplicate = extractedData.some((other: any, i: number) => {
                          if (i === idx) return false;
                        const matchUPC = normalize(d.upc).length > 0 && normalize(d.upc) === normalize(other.upc);
                        const matchCat = normalize(d.catalogNumber).length > 0 && normalize(d.catalogNumber) === normalize(other.catalogNumber);
                        const matchName = normalize(d.releaseName).length > 0 && normalize(d.releaseName) === normalize(other.releaseName);
                          return matchUPC || matchCat || matchName;
                        });
                        return isDuplicate ? !!d.catalogStoreDelivery : true;
                      }
                    );
                    if (!allSelected) {
                      alert(
                        "Please select a delivery destination for all catalogue numbers.",
                      );
                      return;
                    }
                    const sortedData = [...extractedData].sort(
                      (a: any, b: any) => {
                        if (a.catalogStoreDelivery === "Streaming") return -1;
                        if (b.catalogStoreDelivery === "Streaming") return 1;
                        return 0;
                      },
                    );
                    setExtractedData(sortedData);
                    setShowUpcPopup(false);
                  }}
                  className="px-6 py-3 bg-[#00AEEF] text-white font-bold rounded-xl hover:bg-[#009CE0] active:scale-[0.98] transition-all shadow-md shadow-[#00AEEF]/20"
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        )}

      {/* Missing URL Popup */}
      {showMissingUrlPopup && (
        <div className="fixed inset-0 bg-slate-900/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6 lg:p-8">
            <h3 className="text-xl font-bold text-slate-900 mb-4 font-sans">
              Missing Information Detected
            </h3>
            <div className="space-y-4 mb-8">
              {missingInfoTypes.urls && (
                <p className="text-sm text-slate-600 leading-relaxed font-sans">
                  You may have forgotten to add your <strong>Spotify URL</strong> and <strong>Instagram URL</strong>. We use this information to pitch to other DSPs and opportunities
                  on your behalf outside of download stores. If you do not submit
                  these URL's, we cannot apply for these opportunities.
                </p>
              )}
            </div>
            <div className="flex justify-end gap-3 flex-wrap">
              <button
                type="button"
                onClick={() => setShowMissingUrlPopup(false)}
                className="px-6 py-3 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 active:scale-[0.98] transition-all"
              >
                Go Back
              </button>
              <button
                type="button"
                onClick={(e) => {
                  setShowMissingUrlPopup(false);
                  handleSubmit(e, true);
                }}
                className="px-6 py-3 bg-[#00AEEF] text-white font-bold rounded-xl hover:bg-[#009CE0] active:scale-[0.98] transition-all shadow-md shadow-[#00AEEF]/20"
              >
                Submit Pitch
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-sky-50 border-b border-sky-100 px-6 py-3 text-center w-full z-50">
        <p className="text-sm font-medium text-slate-700">
          Check out the opportunities, tools, and services at {" "}
          <a href="https://greenroom.beatport.com/" target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 underline font-bold transition-colors">
            Beatport for Artists and Labels.
          </a>
        </p>
      </div>

      {/* Header Navigation */}
      <nav className="h-20 px-6 lg:px-12 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
        <div className="flex items-center">
          <span className="text-3xl tracking-tighter text-slate-900 mr-8">
            <strong className="font-cal font-black text-[#00AEEF]">Amp</strong>
            <span className="font-bold relative -left-0.5">suite</span>
          </span>
          <div className="hidden sm:flex gap-2 bg-slate-100 p-1 rounded-xl">
             <button
                onClick={() => setActiveTab('pitch')}
                className={`px-5 py-2 font-bold rounded-lg transition-all ${activeTab === 'pitch' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
             >
                DSP Pitching
             </button>
             <button
                onClick={() => setActiveTab('schedule')}
                className={`px-5 py-2 font-bold rounded-lg transition-all ${activeTab === 'schedule' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
             >
                Release Schedule & Reminders
             </button>
             <button
                onClick={() => setActiveTab('marketing')}
                className={`px-5 py-2 font-bold rounded-lg transition-all ${activeTab === 'marketing' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
             >
                Quarterly Label Meeting
             </button>
          </div>
        </div>
      </nav>

      <AnimatePresence mode="wait">
      {activeTab === 'schedule' ? (
        <motion.div key="schedule" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} className="flex-1 w-full flex flex-col">
          <ScheduleReminders />
        </motion.div>
      ) : activeTab === 'marketing' ? (
        <motion.div key="marketing" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} className="flex-1 w-full flex flex-col">
          <QuarterlyLabelMarketing />
        </motion.div>
      ) : (
      <motion.main key="pitching" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} className="flex-1 flex flex-col lg:flex-row gap-12 p-6 lg:p-12 max-w-[1400px] mx-auto w-full animate-in fade-in duration-500">
        {/* Left: Content & Context */}
        <div className="w-full lg:w-1/3 flex flex-col lg:sticky lg:top-12 lg:self-start lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto pb-8 no-scrollbar">
          <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
            DSP Pitching Form
          </h1>
          <p className="text-lg text-slate-500 leading-relaxed mb-6">
            Please upload your label copies for your upcoming release into the
            uploader below. Or, if you need to update an existing pitch, you can retrieve it.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => setShowLookupModal(true)}
              className="px-6 py-2.5 bg-sky-50 text-sky-700 font-bold border border-sky-200 rounded-xl hover:bg-sky-100 transition-colors flex items-center"
            >
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              Retrieve Existing Pitch
            </button>
          </div>

          <div className="mt-10 p-6 bg-sky-50 rounded-2xl border border-sky-100">
            <h4 className="text-sky-900 font-semibold mb-2">Need Help?</h4>
            <p className="text-sky-700 text-sm opacity-80 mb-3">
              You can download your label copies by moving your mouse over any
              release in your Ampsuite portal by selecting 'Export'. If there is
              more than one UPC and CAT number for your release, please add all
              of them into here at once.
            </p>
            <p className="text-sky-700 text-sm opacity-80 mb-3">
              You can pitch for multiple releases at once. Simply click to upload or drag and drop your label copies into the uploader below.
            </p>
            <p className="text-sky-700 text-sm opacity-80">
              If you are having trouble using this pitching form, please reach
              out to{" "}
              <a
                href="mailto:marketing@ampsuite.com"
                className="underline hover:text-sky-900 transition-colors"
              >
                marketing@ampsuite.com
              </a>
              .
            </p>
          </div>
        </div>

        {/* Right: Action Form Card */}
        <div className="flex-1 flex flex-col justify-center">
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-3xl shadow-xl shadow-slate-200/60 p-6 sm:p-10 border border-slate-100 relative"
          >
            {status === "error" && (
              <div className="absolute -top-16 left-0 right-0 bg-red-50 border border-red-200 flex items-center p-4 rounded-xl shadow-sm">
                <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
                <span className="text-sm text-red-700 font-medium">
                  {errorMessage}
                </span>
              </div>
            )}

            {/* Upload Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest">
                  LABEL COPY UPLOADER
                </label>
              </div>
              <div
                className={`relative border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center transition-all group ${
                  isDraggingLabelCopy
                    ? "border-sky-500 bg-sky-50"
                    : "border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-sky-300"
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <label
                  htmlFor="file-upload"
                  className={`cursor-pointer flex flex-col items-center w-full ${isDraggingLabelCopy ? 'pointer-events-none' : ''}`}
                >
                  <svg
                    className={`w-10 h-10 mb-3 transition-colors ${
                      isDraggingLabelCopy
                        ? "text-sky-500 animate-bounce"
                        : "text-slate-300 group-hover:text-sky-400"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="1.5"
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                  <div className="flex flex-col items-center text-center">
                    <span className="font-medium text-slate-600 transition-colors">
                      {isDraggingLabelCopy ? "Drop files here!" : "Click to upload or drag and drop"}
                    </span>
                    <input
                      id="file-upload"
                      name="file"
                      type="file"
                      multiple
                      accept=".xlsx"
                      className="sr-only"
                      onChange={handleFileChange}
                    />
                    {droppedLabelCopyMessage ? (
                      <p className="text-emerald-500 font-semibold text-sm mt-3 animate-pulse">
                        {droppedLabelCopyMessage}
                      </p>
                    ) : (
                      <p className="text-slate-400 text-xs mt-2">
                        Maximum file size 25MB (.xlsx)
                      </p>
                    )}
                  </div>
                </label>
                {isExtracting ? (
                  <div className="mt-6 w-full flex flex-col items-center">
                    <div className="w-full bg-sky-100 rounded-full h-2.5 mb-3 overflow-hidden shadow-inner">
                      <div
                        className="bg-[#00AEEF] h-2.5 rounded-full transition-all duration-300 ease-out"
                        style={{ width: `${extractProgress}%` }}
                      ></div>
                    </div>
                    <div className="w-full flex justify-between items-center text-xs text-sky-800 font-medium">
                      <span className="flex items-center">
                        <Loader2 className="w-3.5 h-3.5 text-[#00AEEF] mr-2 animate-spin" />
                        Analyzing files & extracting data...
                      </span>
                      <span>{Math.min(100, extractProgress)}%</span>
                    </div>
                  </div>
                ) : files.length > 0 ? (
                  <div className="mt-4 w-full flex flex-col gap-2">
                    {files.map((file, index) => (
                      <div
                        key={index}
                        className="px-4 py-3 bg-sky-50 border border-sky-100 rounded-xl text-sm text-sky-800 font-medium flex items-center justify-between"
                      >
                        <div className="flex items-center overflow-hidden">
                          <CheckCircle2 className="w-4 h-4 text-sky-500 mr-2 shrink-0" />
                          <span className="truncate">{file.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>

            {/* Extracted Data Editing Section */}
            {extractedData && (
              <div className="mb-8 pt-8 border-t border-slate-100">
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center">
                    Artist & Release Details
                    <button
                      type="button"
                      onClick={() =>
                        setIsExtractedDataCollapsed(!isExtractedDataCollapsed)
                      }
                      className="ml-4 text-sky-500 hover:text-sky-700 transition-colors flex items-center gap-1 normal-case text-[11px]"
                    >
                      {isExtractedDataCollapsed
                        ? "Show Details"
                        : "Collapse Details"}
                      <svg
                        className={`w-3.5 h-3.5 transition-transform ${isExtractedDataCollapsed ? "rotate-180" : ""}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </button>
                  </label>
                  <button
                    type="button"
                    onClick={handleManualEntryAdd}
                    className="text-xs bg-sky-50 text-sky-600 font-bold px-3 py-1.5 rounded-lg border border-sky-100 hover:bg-sky-100 transition-colors shrink-0"
                  >
                    + Add Another Release
                  </button>
                </div>
                {!isExtractedDataCollapsed && (
                  <>
                    <p className="text-sm text-slate-500 mb-6">
                      Review the extracted details below. Please fill in any
                      incomplete or missing information.
                    </p>
                    <div className="space-y-6">
                      {(() => {
                        const dataArray = Array.isArray(extractedData)
                          ? extractedData
                          : [extractedData];
                        const sortedWithOriginalIndex = dataArray.map(
                          (data, index) => ({ data, originalIndex: index }),
                        );

                        sortedWithOriginalIndex.sort((a, b) => {
                          const normalize = (s: any) =>
                            String(s || "")
                              .toLowerCase()
                              .trim();
                          const getGroupKey = (item: {
                            data: any;
                            originalIndex: number;
                          }) => {
                            if (normalize(item.data.upc))
                              return "1_" + normalize(item.data.upc);
                            if (normalize(item.data.catalogNumber))
                              return "2_" + normalize(item.data.catalogNumber);
                            if (normalize(item.data.releaseName))
                              return "3_" + normalize(item.data.releaseName);
                            return "9_" + item.originalIndex;
                          };
                          const keyA = getGroupKey(a);
                          const keyB = getGroupKey(b);
                          if (keyA !== keyB) return keyA.localeCompare(keyB);
                          return a.originalIndex - b.originalIndex;
                        });

                        return sortedWithOriginalIndex;
                      })().map(
                        ({ data, originalIndex }, sortedIndex, sortedArray) => {
                          const index = originalIndex;
                          const currentData = Array.isArray(extractedData)
                            ? extractedData
                            : [extractedData];

                          let groupedWithIndex = -1;
                          if (sortedIndex > 0) {
                            for (let i = 0; i < sortedIndex; i++) {
                              const prevItem = sortedArray[i];
                              const prev = prevItem.data;
                              if (
                                (data.upc && prev.upc === data.upc) ||
                                (data.catalogNumber &&
                                  prev.catalogNumber === data.catalogNumber) ||
                                (data.releaseName &&
                                  prev.releaseName === data.releaseName &&
                                  data.releaseName.length > 0)
                              ) {
                                groupedWithIndex = prevItem.originalIndex;
                                break;
                              }
                            }
                          }

                        return (
                          <div
                            key={index}
                            className="p-5 bg-slate-50/50 border border-slate-200 rounded-2xl shadow-sm relative"
                          >
                            <div className="absolute top-0 right-0 flex items-center">
                              {groupedWithIndex !== -1 && (
                                <div className="bg-fuchsia-100 text-fuchsia-800 text-[10px] font-bold px-3 py-1 rounded-bl-lg uppercase flex items-center border-b border-l border-fuchsia-200">
                                  <svg
                                    className="w-3 h-3 mr-1"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                  >
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth="2"
                                      d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                                    />
                                  </svg>
                                  Linked to{" "}
                                  {currentData[groupedWithIndex]?.releaseName
                                    ? `'${currentData[groupedWithIndex].releaseName}'`
                                    : `Release ${groupedWithIndex + 1}`}
                                </div>
                              )}
                              {Array.isArray(extractedData) &&
                                extractedData.length > 1 && (
                                  <div
                                    className={`text-[10px] font-bold px-3 py-1 ${groupedWithIndex !== -1 ? "" : "rounded-bl-lg"} uppercase border-b border-l border-slate-200 ${groupedWithIndex !== -1 ? "bg-slate-100 text-slate-500" : "bg-sky-100 text-sky-800"}`}
                                  >
                                    Release {index + 1}
                                  </div>
                                )}
                              <button
                                type="button"
                                onClick={() => handleManualEntryRemove(index)}
                                title="Remove Entry"
                                className="bg-slate-200 text-slate-500 hover:bg-red-100 hover:text-red-600 transition-colors px-2.5 py-1 rounded-tr-xl rounded-bl-lg flex items-center justify-center"
                              >
                                <svg
                                  className="w-3.5 h-3.5"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth="2.5"
                                    d="M6 18L18 6M6 6l12 12"
                                  />
                                </svg>
                              </button>
                            </div>

                            <div className="flex items-center justify-between mt-2">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center shrink-0 border border-slate-200">
                                  {data.artworkPreview || data.artworkUrl ? (
                                    <img src={data.artworkPreview || (data.artworkUrl && data.artworkUrl.includes("drive.google.com") ? `/api/proxy-image?url=${encodeURIComponent(data.artworkUrl)}` : data.artworkUrl)} className="w-full h-full object-cover rounded-lg" alt="Artwork" />
                                  ) : (
                                    <Music className="w-5 h-5 text-slate-400" />
                                  )}
                                </div>
                                <div className="flex flex-col">
                                  <h3 className="font-bold text-slate-800 tracking-tight text-sm">
                                    {data.releaseName || "New Release"}
                                  </h3>
                                  <p className="text-xs font-medium text-slate-500">
                                    {data.artistName || "Unknown Artist"} {data.catalogNumber ? `• ${data.catalogNumber}` : ""}
                                  </p>
                                </div>
                              </div>
                              <button 
                                type="button" 
                                onClick={() => toggleDetails(index)} 
                                className="text-[10px] uppercase tracking-widest font-bold text-sky-600 bg-sky-50 px-3 py-1.5 rounded-lg hover:bg-sky-100 transition-colors flex items-center gap-1"
                              >
                                {expandedDetails.has(index) ? (
                                  <>Hide Details <ChevronUp className="w-3 h-3" /></>
                                ) : (
                                  <>Edit Details <ChevronDown className="w-3 h-3" /></>
                                )}
                              </button>
                            </div>

                            {expandedDetails.has(index) && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5 mt-4 pt-4 border-t border-slate-200">
                              <div className="col-span-1 sm:col-span-2 md:col-span-1">
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Artist Name{" "}
                                  <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="text"
                                  value={data.artistName || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "artistName",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.artistName ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. The Chemical Brothers"
                                  required
                                />
                              </div>
                              <div className="col-span-1 sm:col-span-2 md:col-span-1">
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Release Name{" "}
                                  <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="text"
                                  value={data.releaseName || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "releaseName",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.releaseName ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. Surrender"
                                  required
                                />
                              </div>
                              <div className="col-span-1 sm:col-span-2 md:col-span-1">
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Label Name
                                </label>
                                <input
                                  type="text"
                                  value={data.labelName || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "labelName",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.labelName ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. ODA Recordings"
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Genre <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="text"
                                  value={data.genre || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "genre",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.genre ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. Electronic"
                                  required
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Format
                                </label>
                                <select
                                  value={data.releaseFormat || "Single"}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "releaseFormat",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.releaseFormat ? "bg-white border-slate-200 text-slate-800" : "bg-slate-50 border-slate-200 text-slate-600"}`}
                                >
                                  <option value="Single">Single</option>
                                  <option value="EP">EP</option>
                                  <option value="Album">Album</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Catalogue Number{" "}
                                  <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="text"
                                  value={data.catalogNumber || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "catalogNumber",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.catalogNumber ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. AMP001"
                                  required
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  UPC <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="text"
                                  value={data.upc || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "upc",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.upc ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="12-digit code"
                                  required
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Release Date{" "}
                                  <span className="text-red-400">*</span>
                                </label>
                                <input
                                  type="date"
                                  value={data.releaseDate || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "releaseDate",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.releaseDate ? "bg-white border-slate-200 text-slate-800" : "bg-slate-50 border-slate-200 text-slate-400"}`}
                                  required
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Exclusive Release Date
                                </label>
                                <input
                                  type="date"
                                  value={data.exclusiveReleaseDate || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "exclusiveReleaseDate",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.exclusiveReleaseDate ? "bg-white border-slate-200 text-slate-800" : "bg-slate-50 border-slate-200 text-slate-400"}`}
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Exclusive Store
                                </label>
                                <input
                                  type="text"
                                  value={data.exclusiveStore || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "exclusiveStore",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.exclusiveStore ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. Beatport"
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Preorder Date
                                </label>
                                <input
                                  type="date"
                                  value={data.preorderDate || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "preorderDate",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.preorderDate ? "bg-white border-slate-200 text-slate-800" : "bg-slate-50 border-slate-200 text-slate-400"}`}
                                />
                              </div>
                              <div>
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Vocals Language
                                </label>
                                <input
                                  type="text"
                                  value={data.vocalsLanguage || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "vocalsLanguage",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${data.vocalsLanguage ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="e.g. English"
                                />
                              </div>
                              <div className="col-span-1 sm:col-span-2 md:col-span-3">
                                <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                  Biography / Notes
                                </label>
                                <textarea
                                  rows={2}
                                  value={data.biography || ""}
                                  onChange={(e) =>
                                    handleExtractedDataChange(
                                      index,
                                      "biography",
                                      e.target.value,
                                    )
                                  }
                                  className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all resize-y ${data.biography ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  placeholder="Short biography..."
                                ></textarea>
                              </div>
                            </div>
                            )}

                              {/* Focus Track */}
                              {(data.tracks && data.tracks.length > 1) && (
                                <div className="mt-4 pt-4 border-t border-slate-200">
                                  <div className="bg-sky-50/50 p-3 rounded-xl border border-sky-200 flex items-center">
                                    <label className="block text-[11px] font-semibold text-sky-700 uppercase mr-4 whitespace-nowrap">
                                      Focus Track <span className="text-red-400">*</span>
                                    </label>
                                    {data.tracks && data.tracks.length > 0 ? (
                                      <select
                                        value={data.focusTrack || ""}
                                        required
                                        onChange={(e) => {
                                          const selectedTitle = e.target.value;
                                          handleExtractedDataChange(
                                            index,
                                            "focusTrack",
                                            selectedTitle,
                                          );
                                          const selectedTrack = data.tracks.find(
                                            (t: any) =>
                                              (t?.title || t) === selectedTitle,
                                          );
                                          if (
                                            selectedTrack &&
                                            selectedTrack.isrc
                                          ) {
                                            handleExtractedDataChange(
                                              index,
                                              "isrc",
                                              selectedTrack.isrc,
                                            );
                                          } else {
                                            handleExtractedDataChange(
                                              index,
                                              "isrc",
                                              "",
                                            );
                                          }
                                        }}
                                        className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${
                                          hasAttemptedSubmit && !data.focusTrack
                                            ? "border-red-400 bg-red-50/50 ring-2 ring-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                                            : data.focusTrack
                                              ? "bg-white border-sky-200 text-slate-800"
                                              : "bg-slate-50 border-sky-200 text-slate-600"
                                        }`}
                                      >
                                        <option value="" disabled>
                                          Select focus track...
                                        </option>
                                        {data.tracks.map(
                                          (track: any, i: number) => (
                                            <option
                                              key={i}
                                              value={track?.title || track}
                                            >
                                              {track?.title || track}
                                            </option>
                                          ),
                                        )}
                                      </select>
                                    ) : (
                                      <input
                                        type="text"
                                        value={data.focusTrack || ""}
                                        required
                                        onChange={(e) =>
                                          handleExtractedDataChange(
                                            index,
                                            "focusTrack",
                                            e.target.value,
                                          )
                                        }
                                        className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all ${
                                          hasAttemptedSubmit && !data.focusTrack
                                            ? "border-red-400 bg-red-50/50 ring-2 ring-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                                            : data.focusTrack
                                              ? "bg-white border-sky-200 text-slate-800 placeholder:text-sky-300"
                                              : "bg-slate-50 border-sky-200 text-slate-600 placeholder:text-sky-400"
                                        }`}
                                        placeholder="Name of focus track..."
                                      />
                                    )}
                                  </div>
                                </div>
                              )}

                              {/* Custom Per-Release Details */}
                              <div className="col-span-1 sm:col-span-2 md:col-span-3 mt-4 pt-4 border-t border-slate-200">
                                <div className="flex items-center justify-between mb-4">
                                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                                    Promotion & Marketing Assets
                                  </label>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                                  <div className="col-span-1 sm:col-span-2">
                                    <div className="flex items-center mb-2">
                                      <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                        Listening Link URL{" "}
                                        <span className="text-red-400">*</span>
                                      </label>
                                      <div className="relative group ml-1.5 flex items-center">
                                        <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                        <div className="absolute bottom-[100%] pb-2 -left-3 w-56 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10 font-normal leading-relaxed pointer-events-none">
                                          <div className="p-2 bg-slate-800 text-white text-[10px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                            Required listening link for the
                                            release
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <div
                                      className={`flex items-center px-3 py-2 border rounded-lg focus-within:border-sky-400 focus-within:ring-1 focus-within:ring-sky-100 transition-all ${data.listeningUrl ? (isValidListeningUrl(data.listeningUrl) ? "bg-white border-slate-200" : "bg-red-50 border-red-300") : (hasAttemptedSubmit ? "bg-red-50/50 border-red-400 ring-2 ring-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)]" : "bg-slate-50 border-red-300")}`}
                                    >
                                      <input
                                        type="text"
                                        placeholder="https://..."
                                        value={data.listeningUrl || ""}
                                        onChange={(e) =>
                                          handleExtractedDataChange(
                                            index,
                                            "listeningUrl",
                                            e.target.value,
                                          )
                                        }
                                        required
                                        className={`bg-transparent border-none text-sm w-full focus:ring-0 outline-none p-0 ${data.listeningUrl ? (isValidListeningUrl(data.listeningUrl) ? "text-slate-800" : "text-red-900") : "text-slate-600 placeholder:text-slate-400"}`}
                                      />
                                    </div>
                                    {data.listeningUrl &&
                                      !isValidListeningUrl(
                                        data.listeningUrl,
                                      ) && (
                                        <p className="text-red-500 text-[10px] mt-1 font-medium">
                                          Please enter a valid URL.
                                        </p>
                                      )}
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                                {data.catalogStoreDelivery !== "Download" && (
                                    <div>
                                      <div className="flex items-center mb-2">
                                        <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                          Spotify URL
                                        </label>
                                        <div className="relative group ml-1.5 flex items-center">
                                          <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                          <div className="absolute bottom-[100%] pb-2 -left-3 w-56 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10 font-normal leading-relaxed pointer-events-none">
                                            <div className="p-2 bg-slate-800 text-white text-[10px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                              Please only provide 1 URL, of the
                                              main artist
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div
                                        className={`flex items-center px-3 py-2 border rounded-lg focus-within:border-sky-400 focus-within:ring-1 focus-within:ring-sky-100 transition-all ${data.spotifyUrl ? (isValidSpotifyUrl(data.spotifyUrl) ? "bg-white border-slate-200" : "bg-red-50 border-red-300") : "bg-slate-50 border-slate-200"}`}
                                      >
                                        <span
                                          className={`${data.spotifyUrl ? (isValidSpotifyUrl(data.spotifyUrl) ? "text-emerald-500" : "text-red-400") : "text-slate-400"} mr-2 shrink-0 transition-colors`}
                                        >
                                          <svg
                                            className="w-4 h-4 fill-current"
                                            viewBox="0 0 24 24"
                                          >
                                            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.503 17.306c-.216.354-.678.468-1.032.253-2.85-1.742-6.438-2.136-10.662-1.171-.406.092-.816-.164-.908-.57-.092-.406.164-.816.57-.908 4.623-1.057 8.59-.61 11.78 1.341.353.214.468.677.252 1.055zm1.47-3.256c-.272.443-.848.583-1.291.312-3.262-2.003-8.236-2.585-12.094-1.414-.501.152-1.026-.134-1.178-.635-.152-.5.134-1.026.635-1.178 4.41-1.338 9.897-.68 13.626 1.61.442.271.582.848.312 1.291zm.126-3.393c-3.912-2.324-10.363-2.54-14.127-1.398-.6.183-1.233-.166-1.416-.766-.183-.6.166-1.233.766-1.416 4.303-1.306 11.424-1.052 15.932 1.623.54.32.715 1.015.394 1.555-.32.54-1.014.715-1.55.394z" />
                                          </svg>
                                        </span>
                                        <input
                                          type="text"
                                          list="spotifyUrls"
                                          placeholder="open.spotify.com/..."
                                          value={data.spotifyUrl || ""}
                                          onChange={(e) =>
                                            handleExtractedDataChange(
                                              index,
                                              "spotifyUrl",
                                              e.target.value.split(/[\s,]+/)[0],
                                            )
                                          }
                                          className={`bg-transparent border-none text-sm w-full focus:ring-0 outline-none p-0 ${data.spotifyUrl ? (isValidSpotifyUrl(data.spotifyUrl) ? "text-slate-800" : "text-red-900") : "text-slate-600 placeholder:text-slate-400"}`}
                                        />
                                      </div>
                                      {data.spotifyUrl &&
                                        !isValidSpotifyUrl(data.spotifyUrl) && (
                                          <p className="text-red-500 text-[10px] mt-1 font-medium">
                                            Please enter a valid Spotify URL.
                                          </p>
                                        )}
                                    </div>
                                  )}
                                  <div>
                                    <div className="flex items-center mb-2">
                                      <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                        Instagram URL
                                      </label>
                                      <div className="relative group ml-1.5 flex items-center">
                                        <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                        <div className="absolute bottom-[100%] pb-2 -left-3 w-56 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10 font-normal leading-relaxed pointer-events-none">
                                          <div className="p-2 bg-slate-800 text-white text-[10px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                            Please only provide 1 URL, of the
                                            main artist
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <div
                                      className={`flex items-center px-3 py-2 border rounded-lg focus-within:border-sky-400 focus-within:ring-1 focus-within:ring-sky-100 transition-all ${data.instagramUrl ? (isValidInstagramUrl(data.instagramUrl) ? "bg-white border-slate-200" : "bg-red-50 border-red-300") : "bg-slate-50 border-slate-200"}`}
                                    >
                                      <span
                                        className={`${data.instagramUrl ? (isValidInstagramUrl(data.instagramUrl) ? "text-pink-500" : "text-red-400") : "text-slate-400"} mr-2 shrink-0 transition-colors`}
                                      >
                                        <svg
                                          className="w-4 h-4 fill-current"
                                          viewBox="0 0 24 24"
                                        >
                                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.058-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.791 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                                        </svg>
                                      </span>
                                      <input
                                        type="text"
                                        list="instagramUrls"
                                        placeholder="instagram.com/..."
                                        value={data.instagramUrl || ""}
                                        onChange={(e) =>
                                          handleExtractedDataChange(
                                            index,
                                            "instagramUrl",
                                            e.target.value.split(/[\s,]+/)[0],
                                          )
                                        }
                                        className={`bg-transparent border-none text-sm w-full focus:ring-0 outline-none p-0 ${data.instagramUrl ? (isValidInstagramUrl(data.instagramUrl) ? "text-slate-800" : "text-red-900") : "text-slate-600 placeholder:text-slate-400"}`}
                                      />
                                    </div>
                                    {data.instagramUrl &&
                                      !isValidInstagramUrl(
                                        data.instagramUrl,
                                      ) && (
                                        <p className="text-red-500 text-[10px] mt-1 font-medium">
                                          Please enter a valid Instagram URL.
                                        </p>
                                      )}
                                  </div>
                                </div>

                                <div className="mb-5">
                                  <div className="flex items-center mb-2">
                                    <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                      Available assets
                                    </label>
                                    <div className="relative group ml-1.5 flex items-center">
                                      <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                      <div className="absolute z-50 bottom-[100%] pb-2 -left-3 w-[85vw] sm:w-[450px] md:w-[500px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all font-normal leading-relaxed pointer-events-auto">
                                        <div className="p-4 bg-slate-800 text-white text-[11px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800 max-h-[70vh] overflow-y-auto no-scrollbar">
                                          <p className="mb-3 text-white">
                                            We can check the videos and assets you have available to apply to such Beatport opportunities like:
                                          </p>
                                          
                                          <div className="space-y-4 mb-4 text-slate-200 border-t border-slate-700 pt-4">
                                            <div>
                                              <a href="https://r2.vidzflow.com/source/6b872229-8f3c-4784-9021-99ddbfc87375.mp4" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:text-sky-300 underline font-bold text-[12px] block mb-1">Drop Of The Week</a>
                                              <p className="mb-1 leading-snug"><strong>Summary:</strong> A celebration highlighting the best moments from clubland, every week.</p>
                                              <p className="mb-1 leading-snug"><strong>Platforms:</strong> Instagram, TikTok, YouTube Shorts, Beatportal</p>
                                              <p className="mt-2 font-semibold text-white">What we'd like to see:</p>
                                              <ul className="list-disc pl-4 space-y-1 mt-1 leading-snug">
                                                <li>Hi-Res video from/of the DJ booth incl. build up, drop and strong reaction from the crowd and the DJ.</li>
                                                <li>If shooting from the DJ booth, avoid simply shooting from behind the DJ, we want to see who it is.</li>
                                                <li>The video must feature the actual drop of the track.</li>
                                                <li>Keep the shot wide enough to capture the crowd and DJ.</li>
                                                <li>Try to capture that maximum impact moment - a good energy and vibe are essential!</li>
                                                <li>Good lighting is important.</li>
                                              </ul>
                                            </div>

                                            <div className="border-t border-slate-700 pt-4">
                                              <a href="https://r2.vidzflow.com/source/500dd24c-193b-4447-95b5-edcd0aada579.mp4" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:text-sky-300 underline font-bold text-[12px] block mb-1">Studio Jam</a>
                                              <p className="mb-1 leading-snug"><strong>Summary:</strong> Give us an insight into your studio process! How did the song come together? What production methods were used?</p>
                                              <p className="mb-1 leading-snug"><strong>Platforms:</strong> TikTok, Beatportal</p>
                                              <p className="mt-2 font-semibold text-white">What we'd like to see:</p>
                                              <ul className="list-disc pl-4 space-y-1 mt-1 leading-snug">
                                                <li>A 30-60 sec video of the artist(s) jamming in the studio.</li>
                                                <li>Feel free to experiment with formats - it can be musical performance, production breakdown or a studio jam.</li>
                                                <li>Creative locations / Outdoor filming are encouraged.</li>
                                                <li>Multiple camera angles are preferred unless one specific angle is particularly compelling.</li>
                                                <li>Submissions need to be high quality, unblurry, with good exposure - we need to see what's happening.</li>
                                                <li>Please don't mention competitors such as Splice and NI.</li>
                                              </ul>
                                            </div>

                                            <div className="border-t border-slate-700 pt-4">
                                              <a href="https://r2.vidzflow.com/source/ea58fa9b-8c89-4534-b6db-ae833fb7017c.mp4" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:text-sky-300 underline font-bold text-[12px] block mb-1">Viral Videos</a>
                                              <p className="mb-1 leading-snug"><strong>Summary:</strong> A great opportunity for artists to engage with the online Beatport community through fun & relatable content. This can range from dancing videos, funny clips, throwback images and performance recordings.</p>
                                              <p className="mb-1 leading-snug"><strong>Platforms:</strong> Instagram, TikTok, YT Shorts, Beatportal</p>
                                              <p className="mt-2 font-semibold text-white">What we'd like to see:</p>
                                              <ul className="list-disc pl-4 space-y-1 mt-1 leading-snug">
                                                <li>A positive and encouraging video sparking interactions and engagements. Feel free to get creative here!</li>
                                                <li>Content showcasing enthusiasm for music and DJing in electronic music.</li>
                                                <li>Content must be exclusive to Beatport.</li>
                                              </ul>
                                            </div>
                                          </div>

                                          <div className="mb-4 text-slate-200 border-t border-slate-700 pt-4">
                                            <p className="font-bold mb-2 text-white uppercase tracking-wider text-[10px]">Video Deliverable Guidelines</p>
                                            <ul className="list-disc pl-4 space-y-1">
                                              <li>Label your videos as what they are, for example 'Drop Of The Week' rather than 'VID 2'.</li>
                                              <li>Minimum video resolution 1280 x 720 pixels (720p)</li>
                                              <li>9:16 aspect ratio.</li>
                                              <li>Submissions need to be exclusive.</li>
                                              <li>High quality, unblurry, with good exposure content</li>
                                            </ul>
                                          </div>

                                          <p className="text-white mt-4 border-t border-slate-700 pt-3">
                                            You can find more info on what we can pitch for in this link <a href="https://greenroom.beatport.com/artists#social-spotlight" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:text-sky-300 underline">here</a>
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    className={`flex items-center px-3 py-2 border rounded-lg focus-within:border-sky-400 focus-within:ring-1 focus-within:ring-sky-100 transition-all ${data.assetsUrl ? (isValidListeningUrl(data.assetsUrl) ? "bg-white border-slate-200" : "bg-red-50 border-red-300") : "bg-slate-50 border-slate-200"}`}
                                  >
                                    <input
                                      type="text"
                                      placeholder="https://..."
                                      value={data.assetsUrl || ""}
                                      onChange={(e) =>
                                        handleExtractedDataChange(
                                          index,
                                          "assetsUrl",
                                          e.target.value.split(/[\s,]+/)[0],
                                        )
                                      }
                                      className={`bg-transparent border-none text-sm w-full focus:ring-0 outline-none p-0 ${data.assetsUrl ? (isValidListeningUrl(data.assetsUrl) ? "text-slate-800" : "text-red-900") : "text-slate-600 placeholder:text-slate-400"}`}
                                    />
                                  </div>
                                  {data.assetsUrl &&
                                    !isValidListeningUrl(
                                      data.assetsUrl,
                                    ) && (
                                      <p className="text-red-500 text-[10px] mt-1 font-medium">
                                        Please enter a valid URL.
                                      </p>
                                    )}
                                </div>
                                
                                <div className="mb-5">
                                  <div className="flex items-center mb-2">
                                    <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                      Marketing Drivers{" "}
                                      <span className="text-red-400">*</span>
                                    </label>
                                    <div className="relative group ml-1.5 flex items-center">
                                      <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                      <div className="absolute bottom-[100%] pb-2 -left-3 w-80 sm:w-96 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-20 font-normal leading-relaxed">
                                        <div className="p-4 bg-slate-800 text-white text-[11px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                          <p className="font-bold mb-2 text-white">
                                            Guidelines for Effective Marketing
                                            Drivers:
                                          </p>
                                          <ul className="list-disc pl-4 space-y-1.5 text-slate-200">
                                            <li>
                                              <strong>
                                                Artist Background & Story:
                                              </strong>{" "}
                                              Provide relevant context about the
                                              artist's role in their scene,
                                              recent lineup appearances, their
                                              origin, and notable previous label
                                              releases.
                                            </li>
                                            <li>
                                              <strong>DJ Support:</strong>{" "}
                                              Highlight proven DJ plays (video
                                              links are highly encouraged).
                                            </li>
                                            <li>
                                              <strong>Press & Radio:</strong>{" "}
                                              Include any notable radio spins or
                                              press coverage for the artist or
                                              the current release.
                                            </li>
                                            <li>
                                              <strong>Campaign Context:</strong>{" "}
                                              Mention if this release is part of
                                              a larger campaign (e.g., an album
                                              single). Demonstrating momentum
                                              and a consistent release schedule
                                              is beneficial.
                                            </li>
                                            <li>
                                              <strong>Touring:</strong> Include
                                              upcoming tour dates or schedule
                                              highlights.
                                            </li>
                                          </ul>
                                          <p className="mt-3 text-slate-300 pointer-events-auto">
                                            For further guidance, review our{" "}
                                            <a
                                              href="https://greenroomsupport.beatport.com/hc/en-us/articles/15594109793940-What-are-Beatport-features-and-how-can-I-pitch-my-music-for-promotional-opportunities"
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className="text-sky-400 hover:text-sky-300 underline underline-offset-1 pointer-events-auto"
                                            >
                                              detailed promotional tips
                                            </a>
                                            .
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <textarea
                                    maxLength={1500}
                                    placeholder="Please provide any supporting marketing information for the release..."
                                    value={data.additionalInfo || ""}
                                    onChange={(e) =>
                                      handleExtractedDataChange(
                                        index,
                                        "additionalInfo",
                                        e.target.value,
                                      )
                                    }
                                    required
                                    className={`w-full px-3 py-2 border rounded-lg focus:border-sky-400 focus:ring-1 focus:ring-sky-100 text-sm outline-none transition-all resize-y min-h-[80px] ${data.additionalInfo ? "bg-white border-slate-200 text-slate-800 placeholder:text-slate-300" : "bg-slate-50 border-slate-200 text-slate-600 placeholder:text-slate-400"}`}
                                  />
                                  <div className="text-xs text-right mt-1 opacity-50">
                                    {(data.additionalInfo || "").length} / 1500 limit
                                  </div>
                                </div>
                                
                                <div key="url" className="mb-5">
                                  <div className="flex items-center mb-2">
                                    <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                      Press Release URL
                                    </label>
                                  </div>
                                  <div className="flex items-center px-3 py-2 border rounded-lg focus-within:border-sky-400 focus-within:ring-1 focus-within:ring-sky-100 transition-all bg-white border-slate-200">
                                    <input
                                      type="text"
                                      placeholder="https://..."
                                      value={data.pressReleaseUrl || ""}
                                      onChange={(e) =>
                                        handleExtractedDataChange(
                                          index,
                                          "pressReleaseUrl",
                                          e.target.value,
                                        )
                                      }
                                      className="bg-transparent border-none text-sm w-full focus:ring-0 outline-none p-0 text-slate-800"
                                    />
                                  </div>
                                </div>

                                {data.catalogStoreDelivery !== "Download" && (
                                  <>
                                    <div className="mb-5">
                                      <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-2">
                                        Are We Pitching To Spotify?
                                      </label>
                                      {String(data.artistName || "").toLowerCase().trim() === "various artists" ? (
                                        <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm px-4 py-3 rounded-lg flex items-start">
                                          <AlertCircle className="w-4 h-4 mr-2 mt-0.5 shrink-0" />
                                          <div>
                                            <strong>Not eligible for Spotify:</strong> Releases with an artist name of "Various Artists" cannot be pitched to Spotify. 
                                          </div>
                                        </div>
                                      ) : (
                                        <select
                                          value={data.pitchToSpotify || ""}
                                          required
                                          onChange={(e) =>
                                            handleExtractedDataChange(
                                              index,
                                              "pitchToSpotify",
                                              e.target.value,
                                            )
                                          }
                                          className={`w-full sm:w-1/3 px-3 py-2 rounded-lg focus:outline-none focus:ring-1 focus:border-sky-400 focus:ring-sky-100 text-sm transition-all text-slate-800 ${
                                            hasAttemptedSubmit && !data.pitchToSpotify 
                                              ? "border border-red-400 bg-red-50/50 ring-2 ring-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)]" 
                                              : "bg-white border border-slate-200"
                                          }`}
                                        >
                                          <option value="" disabled>Please select...</option>
                                          <option value="No">No</option>
                                          <option value="Yes">Yes</option>
                                        </select>
                                      )}
                                    </div>

                                    {String(data.artistName || "").toLowerCase().trim() !== "various artists" && data.pitchToSpotify === "Yes" && (
                                      <div className="mb-5 space-y-6 border-l-2 border-sky-200 pl-4 py-2">
                                        <PillSelector
                                          error={hasAttemptedSubmit && (!data.spotifyMoods || data.spotifyMoods.trim() === "")}
                                          required={data.pitchToSpotify === "Yes" && (!data.spotifyMoods || data.spotifyMoods.trim() === "")}
                                          title="Choose up to 2 moods."
                                          options={[
                                            "Chill",
                                            "Energetic",
                                            "Happy",
                                            "Fierce",
                                            "Meditative",
                                            "Psychedelic",
                                            "Romantic",
                                            "Sad",
                                            "Sexy",
                                            "None of these",
                                          ]}
                                          selected={
                                            data.spotifyMoods
                                              ? data.spotifyMoods.split(", ")
                                              : []
                                          }
                                          maxSelection={2}
                                          onChange={(sel) =>
                                            handleExtractedDataChange(
                                              index,
                                              "spotifyMoods",
                                              sel.join(", "),
                                            )
                                          }
                                        />
                                        <PillSelector
                                          error={hasAttemptedSubmit && (!data.spotifyInstruments || data.spotifyInstruments.trim() === "")}
                                          required={data.pitchToSpotify === "Yes" && (!data.spotifyInstruments || data.spotifyInstruments.trim() === "")}
                                          title="What instruments are on this song?"
                                          options={[
                                            "Accordion",
                                            "Acoustic Guitar",
                                            "Banjo",
                                            "Bass Guitar",
                                            "Buzuq",
                                            "Cello",
                                            "Clarinet",
                                            "Djembe",
                                            "Drum Kit",
                                            "Electric Guitar",
                                            "Erhu",
                                            "Flute",
                                            "Harmonica",
                                            "Harp",
                                            "Kora",
                                            "Mandolin",
                                            "Mbira",
                                            "Oboe",
                                            "Organ",
                                            "Oud",
                                            "Pedal Steel Guitar",
                                            "Piano",
                                            "Samples",
                                            "Sanxian",
                                            "Sarod",
                                            "Saxophone",
                                            "Sitar",
                                            "Steel Drum",
                                            "Synthesizer",
                                            "Tabla",
                                            "Trombone",
                                            "Trumpet",
                                            "Ukulele",
                                            "Violin",
                                            "Xylophone",
                                          ]}
                                          selected={
                                            data.spotifyInstruments
                                              ? data.spotifyInstruments
                                                  .split(", ")
                                                  .filter(Boolean)
                                              : []
                                          }
                                          onChange={(sel) =>
                                            handleExtractedDataChange(
                                              index,
                                              "spotifyInstruments",
                                              sel.join(", "),
                                            )
                                          }
                                        />
                                        <PillSelector
                                          error={hasAttemptedSubmit && (!data.spotifyStyles || data.spotifyStyles.trim() === "")}
                                          required={data.pitchToSpotify === "Yes" && (!data.spotifyStyles || data.spotifyStyles.trim() === "")}
                                          title="Choose up to 2 song styles."
                                          options={[
                                            "Acoustic",
                                            "Ballad",
                                            "Beats",
                                            "Christmas",
                                            "Experimental",
                                            "Goth",
                                            "Holiday",
                                            "Kids",
                                            "Traditional",
                                            "None of these",
                                          ]}
                                          selected={
                                            data.spotifyStyles
                                              ? data.spotifyStyles.split(", ")
                                              : []
                                          }
                                          maxSelection={2}
                                          onChange={(sel) =>
                                            handleExtractedDataChange(
                                              index,
                                              "spotifyStyles",
                                              sel.join(", "),
                                            )
                                          }
                                        />
                                        <PillSelector
                                          error={hasAttemptedSubmit && (!data.spotifyCultures || data.spotifyCultures.trim() === "")}
                                          required={data.pitchToSpotify === "Yes" && (!data.spotifyCultures || data.spotifyCultures.trim() === "")}
                                          title="Choose up to 2 music cultures."
                                          options={[
                                            "African",
                                            "Appalachian",
                                            "Arabic",
                                            "Asian",
                                            "Buddhist",
                                            "Caribbean",
                                            "Celtic",
                                            "Christian",
                                            "Hindu",
                                            "Indigenous",
                                            "Islamic",
                                            "Judaic",
                                            "Latin",
                                            "Mediterranean",
                                            "Sikh",
                                            "South Asian",
                                            "None of these",
                                          ]}
                                          selected={
                                            data.spotifyCultures
                                              ? data.spotifyCultures.split(", ")
                                              : []
                                          }
                                          maxSelection={2}
                                          onChange={(sel) =>
                                            handleExtractedDataChange(
                                              index,
                                              "spotifyCultures",
                                              sel.join(", "),
                                            )
                                          }
                                        />
                                      </div>
                                    )}

                                    {String(data.artistName || "").toLowerCase().trim() !== "various artists" && data.pitchToSpotify === "Yes" && (
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-2">
                                      <div className="flex flex-col">
                                        <div className="flex items-center mb-2">
                                          <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                            Spotify Canvas Asset
                                          </label>
                                          <div className="relative group ml-1.5 flex items-center">
                                            <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                            <div className="absolute bottom-[100%] pb-2 -left-3 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10 font-normal leading-relaxed pointer-events-none group-hover:pointer-events-auto">
                                              <div className="p-3 bg-slate-800 text-white text-[11px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                                Canvas is a short loop (3-8s)
                                                playing on Spotify mobile. It
                                                replaces traditional album art,
                                                enriching the listener
                                                experience and driving
                                                engagement.
                                                <br />
                                                <br />
                                                For more details, follow this
                                                link{" "}
                                                <a
                                                  href="https://artists.spotify.com/canvas"
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="underline hover:text-sky-300"
                                                >
                                                  here
                                                </a>
                                                .
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          onDragOver={(e) =>
                                            handleDragOverCanvas(e, index)
                                          }
                                          onDragLeave={handleDragLeaveCanvas}
                                          onDrop={(e) =>
                                            handleDropCanvas(e, index)
                                          }
                                          onClick={() =>
                                            document
                                              .getElementById(
                                                `canvas-upload-${index}`,
                                              )
                                              ?.click()
                                          }
                                          className={`relative border border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                                            isDraggingCanvas === index
                                              ? "border-sky-500 bg-sky-50"
                                              : data.isUploadingCanvas
                                                ? "border-sky-300 bg-sky-50"
                                                : "border-slate-300 hover:border-sky-300 hover:bg-slate-50 bg-white"
                                          }`}
                                        >
                                          <input
                                            id={`canvas-upload-${index}`}
                                            type="file"
                                            accept="video/mp4, image/jpeg"
                                            onChange={(e) =>
                                              handleValidateCanvas(e, index)
                                            }
                                            className="hidden"
                                          />
                                          <div className={isDraggingCanvas === index ? "pointer-events-none" : ""}>
                                          {data.isUploadingCanvas ? (
                                            <div className="flex flex-col items-center py-2">
                                              <Loader2 className="w-5 h-5 animate-spin text-sky-500 mb-2" />
                                              <span className="text-[10px] font-semibold text-sky-600 uppercase">
                                                Uploading...
                                              </span>
                                            </div>
                                          ) : data.spotifyCanvasUrl ? (
                                            <div className="flex flex-col items-center py-2 text-emerald-600">
                                              <CheckCircle2 className="w-5 h-5 mb-1" />
                                              <span className="text-[10px] font-semibold uppercase">
                                                Uploaded
                                              </span>
                                            </div>
                                          ) : (
                                            <div className={`flex flex-col items-center transition-colors ${isDraggingCanvas === index ? "text-sky-500" : "text-slate-500"}`}>
                                              <UploadCloud className={`w-5 h-5 mb-1 transition-transform ${isDraggingCanvas === index ? "animate-bounce text-sky-500" : "text-slate-300"}`} />
                                              <span className="text-[10px]">
                                                {isDraggingCanvas === index ? "Drop canvas here!" : "Drag & drop or Click (MP4/JPEG)"}
                                              </span>
                                            </div>
                                          )}
                                          </div>
                                        </div>
                                        {data.canvasValidation && (
                                          <div className="text-[10px] text-slate-500 mt-2">
                                            <div
                                              className={`p-2 rounded-md ${data.canvasValidation.valid ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}
                                            >
                                              {!data.canvasValidation.valid && (
                                                <ul className="list-disc list-inside">
                                                  <span className="flex items-center font-bold mb-1">
                                                    <AlertCircle className="w-3 h-3 mr-1" />{" "}
                                                    Error:
                                                  </span>
                                                  {data.canvasValidation.errors.map(
                                                    (e: string, i: number) => (
                                                      <li key={i}>{e}</li>
                                                    ),
                                                  )}
                                                </ul>
                                              )}
                                            </div>
                                          </div>
                                        )}
                                        <div className="mt-3">
                                          <p className="font-semibold text-[10px] text-slate-600 mb-1">
                                            Canvas Requirements:
                                          </p>
                                          <ul className="list-disc list-inside space-y-0.5 text-[9px] text-slate-500">
                                            <li>
                                              URLs and CTAs are prohibited
                                            </li>
                                            <li>
                                              If used, text should be relevant
                                              to the track
                                            </li>
                                            <li>
                                              Canvases that don't follow
                                              policies will be removed
                                            </li>
                                            <li>
                                              9:16 ratio, At least 720px tall
                                            </li>
                                          </ul>
                                        </div>
                                      </div>

                                      <div className="flex flex-col">
                                        <div className="flex items-center mb-2">
                                          <label className="block text-[11px] font-semibold text-slate-500 uppercase">
                                            Spotify Clips Asset
                                          </label>
                                          <div className="relative group ml-1.5 flex items-center">
                                            <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" />
                                            <div className="absolute bottom-[100%] pb-2 -left-3 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10 font-normal leading-relaxed pointer-events-none group-hover:pointer-events-auto">
                                              <div className="p-3 bg-slate-800 text-white text-[11px] rounded-lg shadow-xl relative before:absolute before:top-full before:left-4 before:-ml-1 before:border-4 before:border-transparent before:border-t-slate-800">
                                                Clips are short, vertical videos
                                                (under 30s) providing background
                                                story or visual accompaniment to
                                                your artist profile and tracks,
                                                improving discoverability.
                                                <br />
                                                <br />
                                                For more details, follow this
                                                link{" "}
                                                <a
                                                  href="https://artists.spotify.com/clips"
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="underline hover:text-sky-300"
                                                >
                                                  here
                                                </a>
                                                .
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div
                                          onDragOver={(e) =>
                                            handleDragOverClips(e, index)
                                          }
                                          onDragLeave={handleDragLeaveClips}
                                          onDrop={(e) =>
                                            handleDropClips(e, index)
                                          }
                                          onClick={() =>
                                            document
                                              .getElementById(
                                                `clips-upload-${index}`,
                                              )
                                              ?.click()
                                          }
                                          className={`relative border border-dashed rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                                            isDraggingClips === index
                                              ? "border-sky-500 bg-sky-50"
                                              : data.isUploadingClips
                                                ? "border-sky-300 bg-sky-50"
                                                : "border-slate-300 hover:border-sky-300 hover:bg-slate-50 bg-white"
                                          }`}
                                        >
                                          <input
                                            id={`clips-upload-${index}`}
                                            type="file"
                                            accept="video/mp4"
                                            onChange={(e) =>
                                              handleValidateClips(e, index)
                                            }
                                            className="hidden"
                                          />
                                          <div className={isDraggingClips === index ? "pointer-events-none" : ""}>
                                          {data.isUploadingClips ? (
                                            <div className="flex flex-col items-center py-2">
                                              <Loader2 className="w-5 h-5 animate-spin text-sky-500 mb-2" />
                                              <span className="text-[10px] font-semibold text-sky-600 uppercase">
                                                Uploading...
                                              </span>
                                            </div>
                                          ) : data.spotifyClipsUrl ? (
                                            <div className="flex flex-col items-center py-2 text-emerald-600">
                                              <CheckCircle2 className="w-5 h-5 mb-1" />
                                              <span className="text-[10px] font-semibold uppercase">
                                                Uploaded
                                              </span>
                                            </div>
                                          ) : (
                                            <div className={`flex flex-col items-center transition-colors ${isDraggingClips === index ? "text-sky-500" : "text-slate-500"}`}>
                                              <UploadCloud className={`w-5 h-5 mb-1 transition-transform ${isDraggingClips === index ? "animate-bounce text-sky-500" : "text-slate-300"}`} />
                                              <span className="text-[10px]">
                                                {isDraggingClips === index ? "Drop clips here!" : "Drag & drop or Click (MP4)"}
                                              </span>
                                            </div>
                                          )}
                                          </div>
                                        </div>
                                        {data.clipsValidation && (
                                          <div className="text-[10px] text-slate-500 mt-2">
                                            <div
                                              className={`p-2 rounded-md ${data.clipsValidation.valid ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}
                                            >
                                              {!data.clipsValidation.valid && (
                                                <ul className="list-disc list-inside">
                                                  <span className="flex items-center font-bold mb-1">
                                                    <AlertCircle className="w-3 h-3 mr-1" />{" "}
                                                    Error:
                                                  </span>
                                                  {data.clipsValidation.errors.map(
                                                    (e: string, i: number) => (
                                                      <li key={i}>{e}</li>
                                                    ),
                                                  )}
                                                </ul>
                                              )}
                                            </div>
                                          </div>
                                        )}
                                        <div className="mt-3">
                                          <p className="font-semibold text-[10px] text-slate-600 mb-1">
                                            Clips Requirements:
                                          </p>
                                          <ul className="list-disc list-inside space-y-0.5 text-[9px] text-slate-500 mb-3">
                                            <li>Vertical with audio</li>
                                            <li>Longer than 3 seconds</li>
                                            <li>Shorter than 30 seconds</li>
                                            <li>At least 1280 x 720 pixels</li>
                                          </ul>
                                          <label className="flex items-start cursor-pointer hover:bg-slate-50 p-2 -mx-2 rounded transition-colors group">
                                            <div className="flex items-center h-4 mt-[1px]">
                                              <input
                                                type="checkbox"
                                                className="w-3.5 h-3.5 rounded border-slate-300 text-sky-500 focus:ring-sky-500 cursor-pointer"
                                                checked={
                                                  !!data.clipsCheckAccess
                                                }
                                                onChange={(e) =>
                                                  handleExtractedDataChange(
                                                    index,
                                                    "clipsCheckAccess",
                                                    e.target.checked,
                                                  )
                                                }
                                              />
                                            </div>
                                            <div className="ml-2 text-[10px] leading-tight flex-1">
                                              <span className="font-medium text-slate-700">
                                                Unsure if your artist has
                                                access?
                                              </span>
                                              <span className="block text-slate-500 mt-0.5 group-hover:text-slate-600 transition-colors">
                                                Tick here for us to be able to
                                                check for you.
                                              </span>
                                            </div>
                                          </label>
                                        </div>
                                      </div>
                                    </div>
                                    )}
                                  </>
                                )}
                              </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Footer Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between pt-8 mt-8 border-t border-slate-100 gap-6">
              <div className="flex-1 w-full sm:max-w-xs">
                <input
                  id="contactEmail"
                  type="email"
                  required
                  name="contactEmail"
                  value={formData.contactEmail || ""}
                  onChange={handleInputChange}
                  placeholder="Contact Email *"
                  className={`w-full bg-slate-50 border text-slate-900 rounded-xl px-4 py-4 focus:outline-none focus:border-sky-500 transition-all font-medium ${
                    hasAttemptedSubmit && missingRequirements.hasMissingContactEmail
                      ? "border-red-400 ring-2 ring-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)] bg-red-50/50"
                      : "border-slate-200 focus:ring-2 focus:ring-sky-500/50"
                  }`}
                />
              </div>
              <div className="flex flex-col sm:flex-row items-center gap-4 sm:w-auto w-full shrink-0">
                <button
                  type="button"
                  onClick={handleClearAll}
                  disabled={status === "submitting"}
                  className="w-full sm:w-auto px-6 py-4 sm:py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl font-bold hover:bg-slate-50 active:scale-[0.98] transition-all disabled:opacity-70 disabled:pointer-events-none whitespace-nowrap"
                >
                  Clear All
                </button>
            <div className="relative group w-full sm:w-auto">
              {hasAttemptedSubmit && missingRequirements.isInvalid && (
                <div className="absolute bottom-[100%] left-1/2 -translate-x-1/2 pb-3 opacity-100 visible transition-all z-10 pointer-events-none whitespace-nowrap">
                  <div className="px-4 py-2.5 bg-red-500 text-white text-[11px] font-bold tracking-wide rounded-lg shadow-xl relative before:absolute before:top-full before:left-1/2 before:-translate-x-1/2 before:border-4 before:border-transparent before:border-t-red-500">
                    Please answer the questions before submitting
                  </div>
                </div>
              )}
              <button
                type="submit"
                onClick={() => {
                  if (missingRequirements.isInvalid) {
                    setHasAttemptedSubmit(true);
                  }
                }}
                disabled={
                  status === "submitting" ||
                  !extractedData ||
                  (Array.isArray(extractedData) && extractedData.length === 0)
                }
                title={
                  (!extractedData ||
                  (Array.isArray(extractedData) && extractedData.length === 0))
                    ? "Please upload a label copy or enter details manually first"
                    : ""
                }
                className={`w-full sm:w-auto px-8 py-4 sm:py-4 rounded-2xl font-bold transition-all flex items-center justify-center whitespace-nowrap ${
                  hasAttemptedSubmit && missingRequirements.isInvalid 
                    ? "bg-red-50 text-red-600 border-2 border-red-200 shadow-[0_0_15px_rgba(239,68,68,0.3)] hover:bg-red-100 hover:shadow-[0_0_20px_rgba(239,68,68,0.4)] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed animate-[pulse_1s_ease-in-out]"
                    : "bg-[#00AEEF] text-white shadow-lg shadow-[#00AEEF]/20 hover:bg-[#009CE0] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed border-2 border-transparent"
                }`}
              >
                {status === "submitting" ? (
                  <>
                    <Loader2 className={`w-5 h-5 animate-spin mr-2 ${hasAttemptedSubmit && missingRequirements.isInvalid ? "text-red-500" : ""}`} />
                    Processing Roster
                  </>
                ) : (
                  "Confirm & Submit Pitch"
                )}
              </button>
            </div>
              </div>
            </div>
          </form>
        </div>
      </motion.main>
      )}
      </AnimatePresence>

      {/* Bottom Status Bar */}
      <footer className="h-12 px-6 lg:px-12 bg-white border-t border-slate-200 flex items-center justify-between text-[10px] uppercase tracking-widest text-slate-400 font-bold shrink-0">
        <span>© {new Date().getFullYear()} Ampsuite</span>
        <div className="flex gap-4 sm:gap-6">
          <span
            className="text-emerald-500 flex items-center gap-1.5"
            title="System Status is fully operational"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
            Optimal
          </span>
        </div>
      </footer>
      </motion.div>
      )}
    </AnimatePresence>
    
    </>
  );
}
