import { google } from "googleapis";

const auth = new google.auth.GoogleAuth({
  credentials: { client_email: "test@example.com", private_key: "dummy" },
  scopes: ["https://www.googleapis.com/auth/drive"],
});

try {
  const drive = google.drive({ version: "v3", auth });
  console.log("Success with GoogleAuth for Drive");
} catch (err: any) {
  console.error("Error with GoogleAuth for Drive:", err.message);
}
