const tests = [
  `"-----BEGIN PRIVATE KEY-----\\nfoo\\nbar\\n-----END PRIVATE KEY-----"`,
  `-----BEGIN PRIVATE KEY-----\\nfoo\\nbar\\n-----END PRIVATE KEY-----`,
  `"-----BEGIN PRIVATE KEY-----\nfoo\nbar\n-----END PRIVATE KEY-----"`,
];

for (const rawKey of tests) {
  const oldWay = rawKey.replace(/"/g, "").replace(/\\n/g, "\n").trim();
  const newWay = rawKey.replace(/^"|"$/g, "").replace(/\\n/g, "\n").trim();
  if (oldWay !== newWay) {
    console.log("Mismatch on:", JSON.stringify(rawKey));
    console.log("Old:", JSON.stringify(oldWay));
    console.log("New:", JSON.stringify(newWay));
  }
}
