import fs from "fs";

async function testUpload() {
  try {
    const formData = new FormData();
    formData.append("file", new Blob([fs.readFileSync("test.ts")]), "test.ts");
    
    const res = await fetch("http://localhost:3000/api/upload", {
      method: "POST",
      body: formData,
    });
    
    console.log("Status:", res.status);
    console.log("Body:", await res.text());
  } catch (err) {
    console.error(err);
  }
}
testUpload();
