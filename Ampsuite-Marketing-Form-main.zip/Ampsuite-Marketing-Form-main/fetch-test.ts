import http from 'http';
import fs from 'fs';
import * as xlsx from 'xlsx';

const wb = xlsx.utils.book_new();
const ws = xlsx.utils.aoa_to_sheet([["Title", "My Track"]]);
xlsx.utils.book_append_sheet(wb, ws, "Metadata");
const buf = xlsx.write(wb, { type: "buffer", bookType: "xlsx" });

const boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW';
const header = `--${boundary}\r\nContent-Disposition: form-data; name="files"; filename="dummy.xlsx"\r\nContent-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n`;
const footer = `\r\n--${boundary}--\r\n`;

const req = http.request({
  hostname: 'localhost',
  port: 3000,
  path: '/api/extract',
  method: 'POST',
  headers: {
    'Content-Type': `multipart/form-data; boundary=${boundary}`,
    'Content-Length': Buffer.byteLength(header) + buf.length + Buffer.byteLength(footer)
  }
}, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => console.log('Status Code:', res.statusCode, 'Data:', data));
});

req.on('error', (e) => {
  console.error('Fetch error:', e);
});

req.write(header);
req.write(buf);
req.write(footer);
req.end();
