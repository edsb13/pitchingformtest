import express from "express";
import { createServer as createViteServer } from "vite";
import { google } from "googleapis";
import multer from "multer";
import fs from "fs";
import * as xlsx from "xlsx";
import path from "path";
import http from "http";
import rateLimit from "express-rate-limit";

// Ensure upload directory exists
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Clean any leftover uploads from a previous crash
for (const f of fs.readdirSync(uploadDir)) {
  try { fs.unlinkSync(path.join(uploadDir, f)); } catch {}
}

process.on("unhandledRejection", (reason) => {
  console.error("Unhandled Rejection:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
});

// --- Multer setup for file uploads ---
const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB limit
});

// --- Consolidated Google Auth Helper ---
const getGoogleAuth = (scopes: string[]) => {
  const clientEmail = process.env.GOOGLE_CLIENT_EMAIL;
  const rawKey = process.env.GOOGLE_PRIVATE_KEY;
  if (!clientEmail || !rawKey) return null;

  // Strip wrapping quotes, unescape literal \n, trim whitespace.
  const privateKey = rawKey
    .replace(/^"|"$/g, "")
    .replace(/\\n/g, "\n")
    .trim();

  return new google.auth.GoogleAuth({
    credentials: { client_email: clientEmail, private_key: privateKey },
    scopes,
  });
};

const getSheetsClient = () => {
  const auth = getGoogleAuth(["https://www.googleapis.com/auth/spreadsheets"]);
  if (!auth) return null;
  return google.sheets({ version: "v4", auth });
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Create HTTP server explicitly for Vite HMR wiring
  const httpServer = http.createServer(app);

  // Cloud Run sits behind Google's load balancer which sets X-Forwarded-For.
  // Trust the first hop so express-rate-limit and req.ip see real client IPs.
  app.set('trust proxy', 1);

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  const pitchLimiter = rateLimit({
    windowMs: 10 * 60 * 1000, // 10 minutes
    limit: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many pitch submissions. Please try again later." },
  });

  // --- Helpers for deterministic extraction ---
  const normalizeLabel = (s: unknown) =>
    String(s ?? "").trim().toLowerCase().replace(/[:\-\s]+$/, "");

  const formatCell = (v: unknown): string => {
    if (v == null) return "";
    if (v instanceof Date) {
      return v.toISOString().slice(0, 10);
    }
    return String(v).trim();
  };

  const FIELD_LABELS: Record<string, string[]> = {
    artistName:    ["artist(s)", "artist", "artists", "artist name"],
    releaseName:   ["title", "release name", "release title"],
    labelName:     ["label", "label name"],
    releaseFormat: ["type", "release type", "format"],
    catalogNumber: ["cat. no.", "cat no", "catalog number", "catalogue number"],
    upc:           ["upc code", "upc"],
    releaseDate:   ["general release date", "release date"],
    exclusiveReleaseDate: ["exclusive release date", "exclusive date"],
    exclusiveStore: ["exclusive store", "store exclusivity", "exclusive"],
    preorderDate:  ["preorder date", "pre-order date", "pre order date"],
    biography:     ["description", "biography", "bio", "release description"],
    contactEmail:  ["contact email", "email"],
    vocalsLanguage: ["vocals language", "vocal language", "language", "vocals", "vocal"],
  };

  type ExtractedRelease = {
    artistName: string; releaseName: string; labelName: string; releaseFormat: string;
    catalogNumber: string; upc: string; releaseDate: string;
    exclusiveReleaseDate?: string; exclusiveStore?: string; preorderDate?: string;
    biography: string; contactEmail: string; genre: string;
    vocalsLanguage: string;
    sheetCount: number;
    tracks: { title: string; isrc: string }[];
    isrc?: string;
    instagramUrl?: string;
    spotifyUrl?: string;
    listeningUrl?: string;
  };

  const extractReleaseFromWorkbook = (workbook: xlsx.WorkBook): ExtractedRelease => {
    const sheetName =
      workbook.SheetNames.find(n => /metadata/i.test(n)) ?? workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1, raw: true, blankrows: false,
    });

    const labelMap = new Map<string, string>();
    for (const row of rows) {
      if (!Array.isArray(row) || row.length < 2) continue;
      const label = normalizeLabel(row[0]);
      const value = formatCell(row[1]);
      if (label && value) labelMap.set(label, value);
    }
    const lookup = (keys: string[]) => {
      for (const k of keys) {
        const v = labelMap.get(k);
        if (v) return v;
      }
      return "";
    };

    let genre = "";
    let vocalsLanguage = lookup(FIELD_LABELS.vocalsLanguage);
    const tracks: { title: string; isrc: string }[] = [];
    let isrc = "";

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!Array.isArray(row)) continue;

      const genreCol = row.findIndex(c => ["genre", "primary genre"].includes(normalizeLabel(c)));
      const vocalsCol = row.findIndex(c => FIELD_LABELS.vocalsLanguage.includes(normalizeLabel(c)));
      const titleCol = row.findIndex(c => ["title", "track title", "track name", "name", "track", "audio", "file name", "filename", "audio file"].includes(normalizeLabel(c)));
      const mixNameCol = row.findIndex(c => ["mix name", "version", "mix", "remix"].includes(normalizeLabel(c)));
      const trackNoCol = row.findIndex(c => ["track number", "track no", "track no.", "#", "no", "no."].includes(normalizeLabel(c)));
      const isrcCol = row.findIndex(c => ["isrc", "isrc code"].includes(normalizeLabel(c)));
      const artistCol = row.findIndex(c => ["artist", "artists", "primary artist", "track artist"].includes(normalizeLabel(c)));

      const matches = [genreCol, vocalsCol, titleCol, mixNameCol, trackNoCol, isrcCol, artistCol].filter(idx => idx !== -1).length;

      // A track-table header must have a Title or ISRC column AND at least one other recognized
      // column. Vertical key/value metadata rows only ever have one recognized label per row,
      // so this rejects them and selects only the real horizontal header.
      if ((titleCol !== -1 || isrcCol !== -1) && matches >= 2) {
        for (let j = i + 1; j < rows.length; j++) {
          const trackRow = rows[j];
          if (!Array.isArray(trackRow)) continue;
          if (genreCol !== -1 && !genre && trackRow[genreCol] != null) {
            genre = formatCell(trackRow[genreCol]);
          }
          if (vocalsCol !== -1 && !vocalsLanguage && trackRow[vocalsCol] != null) {
            vocalsLanguage = formatCell(trackRow[vocalsCol]);
          }
          if (titleCol !== -1 && trackRow[titleCol] != null) {
            const trackVal = formatCell(trackRow[titleCol]);
            const mixVal = mixNameCol !== -1 ? formatCell(trackRow[mixNameCol]) : "";
            if (trackVal) {
              const fullTitle = mixVal ? `${trackVal} - ${mixVal}` : trackVal;
              const trackIsrc = isrcCol !== -1 && trackRow[isrcCol] != null ? formatCell(trackRow[isrcCol]) : "";
              tracks.push({ title: fullTitle, isrc: trackIsrc });
            }
          } else if (isrcCol !== -1 && trackRow[isrcCol] != null) {
            // If there's no title column but there is an ISRC column, still add it
            const trackIsrc = formatCell(trackRow[isrcCol]);
            if (trackIsrc) {
              tracks.push({ title: `Track ${tracks.length + 1}`, isrc: trackIsrc });
            }
          }
        }

        if (tracks.length === 1) {
          isrc = tracks[0].isrc || "";
        } else {
          isrc = "";
        }
        break;
      }
    }

    return {
      artistName:    lookup(FIELD_LABELS.artistName),
      releaseName:   lookup(FIELD_LABELS.releaseName),
      labelName:     lookup(FIELD_LABELS.labelName),
      releaseFormat: lookup(FIELD_LABELS.releaseFormat),
      catalogNumber: lookup(FIELD_LABELS.catalogNumber),
      upc:           lookup(FIELD_LABELS.upc),
      releaseDate:   lookup(FIELD_LABELS.releaseDate),
      exclusiveReleaseDate: lookup(FIELD_LABELS.exclusiveReleaseDate),
      exclusiveStore: lookup(FIELD_LABELS.exclusiveStore),
      preorderDate:  lookup(FIELD_LABELS.preorderDate),
      biography:     lookup(FIELD_LABELS.biography),
      contactEmail:  lookup(FIELD_LABELS.contactEmail),
      genre,
      vocalsLanguage,
      sheetCount:    workbook.SheetNames.length,
      tracks,
      isrc,
    };
  };

  // --- Diagnostic Endpoint ---
  app.get("/api/selftest", (_req, res) => {
    const aoa = [
      ["Title", "Brighton Sunrise"],
      ["Artist(s)", "Nick Hook"],
      ["Type", "Single"],
      ["Copyright", "2026 Jeepers! Music"],
      [],
      ["Track Number","Title","Mix Name","Artist(s)","Track Ref.","ISRC","Genre","Length","Vocals Language"],
      [1, "Brighton Sunrise", "Coming Up Mix", "Nick Hook", "", "GXBNP2601739", "Deep House", "00:06:12", "English"],
      [2, "Brighton Sunrise", "Original Mix", "Nick Hook", "", "GXBNP2601738", "Deep House", "00:06:29", "English"],
    ];
    const ws = xlsx.utils.aoa_to_sheet(aoa);
    const wb: xlsx.WorkBook = { SheetNames: ["Metadata"], Sheets: { Metadata: ws } };
    const result = extractReleaseFromWorkbook(wb);
    res.json({ buildMarker: "selftest-v1", trackCount: result.tracks.length, tracks: result.tracks });
  });

  // --- Extraction Endpoint ---
  app.post("/api/extract", upload.array("files"), async (req, res) => {
    const files = (req.files as Express.Multer.File[]) || [];
    const userEmail = req.body.userEmail || "";
    try {
      const extractedInfo: ExtractedRelease[] = [];

      for (const file of files) {
        if (!file.originalname.toLowerCase().endsWith('.xlsx')) {
          continue;
        }
        try {
          const buffer = await fs.promises.readFile(file.path);
          const workbook = xlsx.read(buffer, { type: "buffer", cellDates: true });
          extractedInfo.push(extractReleaseFromWorkbook(workbook));
        } catch (parseErr) {
          console.error(`Failed to parse ${file.originalname}:`, parseErr);
          return res.status(400).json({
            error: `Could not read "${file.originalname}". Please make sure it matches the standard label-copy template.`,
          });
        }
      }

      // Perform lookup to merge Release Schedules data
      const sheets = getSheetsClient();
      const spreadsheetId = process.env.GOOGLE_SHEET_ID;
      if (sheets && spreadsheetId && extractedInfo.length > 0) {
         try {
           const scheduleResponse = await sheets.spreadsheets.values.get({
             spreadsheetId,
             range: `'Release Schedules'!A:N`, // We need at least up to column L (12th column, index 11)
           });
           const rows = scheduleResponse.data.values || [];
           
           // We create a map of catNo -> extra info, upcCode -> extra info, and email matches
           const extrasByUpc = new Map<string, any>();
           const extrasByCatNo = new Map<string, any>();
           
           for (const row of rows) {
              const catNo = String(row[0] || "").trim().toLowerCase();
              const upc = String(row[1] || "").trim().toLowerCase();
              const spotifyUrl = row[8] || "";
              const instagramUrl = row[9] || "";
              const listeningUrl = row[10] || "";
              const email = String(row[11] || "").trim().toLowerCase();
              
              if (!spotifyUrl && !instagramUrl && !listeningUrl) continue;
              
              const extraData = { spotifyUrl, instagramUrl, listeningUrl };
              
              // Only merge if the email matches (if provided), or if there's no email constraint required here.
              // We'll prioritize UPC matching.
              if (upc) extrasByUpc.set(upc, extraData);
              if (catNo) extrasByCatNo.set(catNo, extraData);
           }
           
           for (const info of extractedInfo) {
              const match = extrasByUpc.get((info.upc || "").trim().toLowerCase()) 
                         || extrasByCatNo.get((info.catalogNumber || "").trim().toLowerCase());
              
              if (match) {
                 if (match.spotifyUrl) info.spotifyUrl = match.spotifyUrl;
                 if (match.instagramUrl) info.instagramUrl = match.instagramUrl;
                 if (match.listeningUrl) info.listeningUrl = match.listeningUrl;
              }
           }
         } catch (sheetErr) {
           console.error("Failed to merge schedule extras automatically:", sheetErr);
         }
      }

      console.log("[extract] returning:", JSON.stringify(extractedInfo.map(r => ({ releaseFormat: r.releaseFormat, trackCount: r.tracks.length }))));
      res.json({ success: true, data: extractedInfo });
    } catch (error) {
      console.error("Extract Error:", error instanceof Error ? `${error.name}: ${error.message}` : error);
      res.status(500).json({ error: "We experienced an issue parsing the file. Please try again later." });
    } finally {
      for (const file of files) {
        fs.unlink(file.path, () => {});
      }
    }
  });

  // --- Google Drive Upload Endpoint ---
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      if (!file) return res.status(400).json({ error: "No file provided" });

      const auth = getGoogleAuth(["https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]);
      if (!auth) {
        throw new Error("Google Credentials missing. Please provide GOOGLE_CLIENT_EMAIL and GOOGLE_PRIVATE_KEY.");
      }

      const drive = google.drive({ version: "v3", auth });

      const fsStream = fs.createReadStream(file.path);

      const requestBody: { name: string; parents?: string[] } = {
        name: file.originalname,
      };

      // Batch 1 fix: require GOOGLE_DRIVE_FOLDER_ID, no hardcoded fallback
      const folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;
      if (!folderId) {
        console.error("GOOGLE_DRIVE_FOLDER_ID not set");
        return res.status(500).json({ error: "We experienced an issue uploading your file. Please try again later." });
      }
      requestBody.parents = [folderId];

      const response = await drive.files.create({
        requestBody,
        media: {
          mimeType: file.mimetype,
          body: fsStream,
        },
        fields: "id, webViewLink, webContentLink",
        supportsAllDrives: true,
      });

      res.json({ url: response.data.webContentLink || response.data.webViewLink });
    } catch (error) {
      console.error("Upload Error:", error instanceof Error ? `${error.name}: ${error.message}` : error);
      res.status(500).json({ error: "We experienced an issue uploading your file. Please try again later." });
    } finally {
      if (req.file) fs.unlink(req.file.path, () => {});
    }
  });

  // --- Image Proxy Endpoint (for PDF artwork CORS workaround & Drive files) ---
  app.get("/api/proxy-image", async (req, res) => {
    try {
      const url = req.query.url;
      if (!url || typeof url !== "string") {
        return res.status(400).json({ error: "Missing 'url' parameter" });
      }

      let parsedUrl: URL;
      try {
        parsedUrl = new URL(url);
      } catch {
        return res.status(400).json({ error: "Invalid URL" });
      }

      // Handle Google Drive links specifically
      if (parsedUrl.hostname === "drive.google.com") {
        const fileIdMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
        if (fileIdMatch && fileIdMatch[1]) {
          const auth = getGoogleAuth(["https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive.readonly", "https://www.googleapis.com/auth/drive"]);
          if (auth) {
             const drive = google.drive({ version: "v3", auth });
             try {
                const response = await drive.files.get(
                  { fileId: fileIdMatch[1], alt: 'media' },
                  { responseType: 'stream' }
                );
                
                // We could explicitly set content type if known, but often piping works
                return response.data.pipe(res);
             } catch (driveErr) {
                console.error("Drive Proxy Error:", driveErr);
                return res.status(500).end();
             }
          }
        }
      }

      // Basic SSRF protection: HTTPS only, deny internal/private hostnames.
      if (parsedUrl.protocol !== "https:") {
        return res.status(400).json({ error: "Only HTTPS URLs allowed" });
      }
      const hostname = parsedUrl.hostname.toLowerCase();
      if (
        hostname === "localhost" ||
        hostname.startsWith("127.") ||
        hostname.startsWith("10.") ||
        hostname.startsWith("192.168.") ||
        hostname.startsWith("169.254.") ||
        /^172\.(1[6-9]|2[0-9]|3[01])\./.test(hostname) ||
        hostname.endsWith(".internal") ||
        hostname === "metadata.google.internal"
      ) {
        return res.status(403).json({ error: "Internal hosts not allowed" });
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      try {
        const upstream = await fetch(url, { signal: controller.signal });
        if (!upstream.ok) {
          return res.status(upstream.status).end();
        }
        const contentType = upstream.headers.get("content-type") || "";

        if (!contentType.startsWith("image/")) {
          return res.status(400).json({ error: "URL does not return an image" });
        }
        const contentLength = parseInt(upstream.headers.get("content-length") || "0", 10);
        if (contentLength > 25 * 1024 * 1024) {
          return res.status(413).json({ error: "Image too large" });
        }

        const buffer = Buffer.from(await upstream.arrayBuffer());
        res.set("Content-Type", contentType);
        res.set("Cache-Control", "public, max-age=86400");
        res.send(buffer);
      } finally {
        clearTimeout(timeoutId);
      }
    } catch (error) {
      console.error("Proxy image error:", error instanceof Error ? `${error.name}: ${error.message}` : error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to proxy image" });
      }
    }
  });

  // --- Pitch Lookup Endpoint ---
  app.get("/api/pitch/lookup", pitchLimiter, async (req, res) => {
    try {
      const { query } = req.query;
      if (!query || typeof query !== "string") {
        return res.status(400).json({ error: "Please provide a UPC or Catalogue Number to search for." });
      }
      
      const sheets = getSheetsClient();
      const spreadsheetId = process.env.GOOGLE_SHEET_ID;
      
      if (!sheets || !spreadsheetId) {
        return res.status(500).json({ error: "Storage not configured." });
      }

      const sheetTab = process.env.GOOGLE_SHEET_TAB_NAME || "Sheet1";
      const response = await sheets.spreadsheets.values.get({
        spreadsheetId,
        range: `'${sheetTab}'!A:AG`,
      });

      const rows = response.data.values;
      if (!rows || rows.length === 0) {
        return res.status(404).json({ error: "No releases found." });
      }

      // Skip header row if it exists. Map rows back to objects
      const items = rows.slice(1).map((row, index) => {
        return {
          _rowIndex: index + 2, // 1-indexed Sheets, plus 1 for header
          releaseDate: row[0] || "",
          exclusiveReleaseDate: row[1] || "",
          exclusiveStore: row[2] || "",
          preorderDate: row[3] || "",
          artistName: row[4] || "",
          releaseName: row[5] || "",
          labelName: row[6] || "",
          releaseFormat: row[7] || "",
          focusTrack: row[8] || "",
          isrc: row[9] || "",
          genre: row[10] || "",
          upc: row[11] || "",
          catalogNumber: row[12] || "",
          catalogStoreDelivery: row[13] || "",
          biography: row[14] || "",
          additionalInfo: row[15] || "",
          instagramUrl: row[16] || "",
          spotifyUrl: row[17] || "",
          vocalsLanguage: row[18] || "",
          pitchToSpotify: row[19] || "",
          spotifyMoods: row[20] || "",
          spotifyInstruments: row[21] || "",
          spotifyStyles: row[22] || "",
          spotifyCultures: row[23] || "",
          spotifyCanvasUrl: row[24] || "",
          spotifyClipsUrl: row[25] || "",
          clipsCheckAccess: row[26] === "Yes",
          listeningUrl: row[27] || "",
          artworkUrl: row[28] || "",
          wantsPressRelease: row[29] || "",
          pressReleaseUrl: row[30] || "",
          assetsUrl: row[31] || "",
          contactEmail: row[33] || "",
        };
      });

      const searchTerm = query.toLowerCase().trim();
      const matches = items.filter(
        item => 
          (item.upc && item.upc.toLowerCase() === searchTerm) || 
          (item.catalogNumber && item.catalogNumber.toLowerCase() === searchTerm)
      );

      if (matches.length === 0) {
        return res.status(404).json({ error: "No release found matching that UPC or Catalogue Number." });
      }

      return res.json({ data: matches });

    } catch (err) {
      console.error("Lookup Error:", err);
      return res.status(500).json({ error: "Failed to perform lookup." });
    }
  });

  // --- Pitch Submission Endpoint ---
  app.post("/api/pitch", pitchLimiter, async (req, res) => {
    try {
      const payload = req.body;
      const pitches = Array.isArray(payload) ? payload : [payload];

      const sheets = getSheetsClient();
      const spreadsheetId = process.env.GOOGLE_SHEET_ID;

      if (!sheets || !spreadsheetId) {
        console.error("Pitch storage not configured: missing GOOGLE_SHEET_ID or Google credentials");
        return res.status(500).json({
          error: "We experienced an issue submitting your pitch. Please try again later.",
        });
      }

      try {
        const sheetTab = process.env.GOOGLE_SHEET_TAB_NAME || "Sheet1";
        
        const rowsToAppend: any[] = [];
        const updatesToExecute: any[] = [];

        pitches.forEach((finalData: any) => {
        const rowData = [
          finalData.releaseDate || "",
          finalData.exclusiveReleaseDate || "",
          finalData.exclusiveStore || "",
          finalData.preorderDate || "",
          finalData.artistName || "",
          finalData.releaseName || "",
          finalData.labelName || "",
          finalData.releaseFormat || "",
          finalData.focusTrack || "",
          finalData.isrc || "",
          finalData.genre || "",
          finalData.upc || "",
          finalData.catalogNumber || "",
          finalData.catalogStoreDelivery || "",
          finalData.biography || "",
          finalData.additionalInfo || "",
          finalData.instagramUrl || "",
          finalData.spotifyUrl || "",
          finalData.vocalsLanguage || "Instrumental",
          finalData.pitchToSpotify || "No",
          finalData.spotifyMoods || "",
          finalData.spotifyInstruments || "",
          finalData.spotifyStyles || "",
          finalData.spotifyCultures || "",
          finalData.spotifyCanvasUrl || "",
          finalData.spotifyClipsUrl || "",
          finalData.clipsCheckAccess ? "Yes" : "",
          finalData.listeningUrl || "",
          finalData.artworkUrl || "",
          finalData.wantsPressRelease || "",
          finalData.pressReleaseUrl || "",
          finalData.assetsUrl || "",
          finalData.contactEmail || "",
        ];

          if (finalData._rowIndex) {
             updatesToExecute.push({
               range: `'${sheetTab}'!A${finalData._rowIndex}:AG${finalData._rowIndex}`,
               values: [rowData],
             });
          } else {
             rowsToAppend.push(rowData);
          }
        });

        if (updatesToExecute.length > 0) {
          for (const update of updatesToExecute) {
            await sheets.spreadsheets.values.update({
              spreadsheetId,
              range: update.range,
              valueInputOption: "USER_ENTERED",
              requestBody: {
                values: update.values,
              },
            });
          }
        }

        if (rowsToAppend.length > 0) {
          await sheets.spreadsheets.values.append({
            spreadsheetId,
            range: `'${sheetTab}'!A:AG`,
            valueInputOption: "USER_ENTERED",
            requestBody: {
              values: rowsToAppend,
            },
          });
        }
      } catch (sheetsErr) {
        console.error("Sheets Error:", sheetsErr);
        return res.status(500).json({
          error: "We experienced an issue submitting your pitch. Please try again later.",
        });
      }

      const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;
      if (slackWebhookUrl) {
        try {
          const slackText = `🎵 *New Pitch Submission*\n\n*Releases:*\n${pitches.map((p: any) => `• ${p.artistName || "Unknown Artist"} - ${p.releaseName || "Unknown Release"}`).join("\n")}\n\nCheck the connected Google Sheet for complete details.`;
          await fetch(slackWebhookUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: slackText }),
          });
        } catch (slackErr) {
          console.error("Failed to send Slack notification:", slackErr);
        }
      }

      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Pitch Error:", error instanceof Error ? `${error.name}: ${error.message}` : error);
      res.status(500).json({ error: "We experienced an issue submitting your pitch. Please try again later." });
    }
  });

  // --- Quarterly Marketing Submission Endpoint ---
  app.post("/api/quarterly-marketing/submit", pitchLimiter, async (req, res) => {
    try {
      const data = req.body;
      const sheets = getSheetsClient();
      const spreadsheetId = process.env.QUARTERLY_MARKETING_SHEET_ID || "1-VLGEIvjkCPPQ4VE54FpC0mx7MuWqLrBpIbMpVk3owk";
      const sheetTab = "Quarterly Label Marketing Notes";

      if (!sheets) {
        console.error("Sheets not configured");
        return res.status(500).json({ error: "Configuration Error" });
      }

      // Map data to the correct columns as per the form layout
      const dsps = Array.isArray(data.importantDSPs) ? data.importantDSPs.join(", ") : "";
      const otherDsp = data.otherDSP ? ` (Other: ${data.otherDSP})` : "";
      
      // Try to get headers first to see if they exist
      try {
        const headerResponse = await sheets.spreadsheets.values.get({
          spreadsheetId,
          range: `'${sheetTab}'!A1:P1`,
        });

        if (!headerResponse.data.values || headerResponse.data.values.length === 0) {
          // Sheet is empty, add headers first
          const headers = [
            "Label Name (A)",
            "Review Period (B)",
            "Upcoming Releases (C)",
            "Main Focus Next 3 Months (D)",
            "Priority Artists (E)",
            "Marketing Activities (F)",
            "Reflection Last Quarter (G)",
            "What Worked Well (H)",
            "What Didn't Work Well (I)",
            "Important DSPs (J)",
            "DSP Activities (K)",
            "Beatport Hype (L)",
            "Biggest Challenge (M)",
            "Additional Comments (N)",
            "Contact Email (O)",
            "Submission Timestamp (P)"
          ];
          
          await sheets.spreadsheets.values.append({
            spreadsheetId,
            range: `'${sheetTab}'!A1:P1`,
            valueInputOption: "USER_ENTERED",
            requestBody: {
              values: [headers],
            },
          });
        }
      } catch (err) {
        console.warn("Could not fetch headers, skipping header injection...", err);
      }

      const rowData = [
        data.labelName || "",
        data.reviewPeriod || "",
        data.upcomingReleases || "",
        data.mainFocusNext3Months || "",
        data.priorityArtists || "",
        data.marketingActivities || "",
        data.reflectionLastQuarter || "",
        data.whatWorkedWell || "",
        data.whatDidNotWorkWell || "",
        dsps + otherDsp,
        data.dspActivities || "",
        data.beatportHype || "",
        data.biggestChallenge || "",
        data.additionalComments || "",
        data.contactEmail || "",
        new Date().toISOString() // Submission Timestamp
      ];

      await sheets.spreadsheets.values.append({
        spreadsheetId,
        range: `'${sheetTab}'!A:P`,
        valueInputOption: "USER_ENTERED",
        requestBody: {
          values: [rowData],
        },
      });

      const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;
      if (slackWebhookUrl) {
        try {
          const slackText = `📈 *New Quarterly Marketing Form Submission*\n\n*Label:* ${data.labelName || "Unknown"}\n*Submitter:* ${data.contactEmail || "Unknown"}\n*Review Period:* ${data.reviewPeriod || "Unknown"}\n\nCheck the connected Google Sheet for complete details.`;
          await fetch(slackWebhookUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: slackText }),
          });
        } catch (slackErr) {
          console.error("Failed to send Slack notification:", slackErr);
        }
      }

      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Quarterly Marketing Submit Error:", error);
      res.status(500).json({ error: "Failed to submit quarterly marketing notes." });
    }
  });

  // --- Parse Schedule Endpoint ---
  app.post("/api/parse-schedule", upload.single("schedule"), async (req, res) => {
    try {
      let data: any[] | null = null;

      if (req.body.scheduleText) {
        // If text is provided, parse it as CSV using xlsx
        const workbook = xlsx.read(req.body.scheduleText, { type: "string", cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        data = xlsx.utils.sheet_to_json(worksheet, { header: 1 });
      } else if (req.file) {
        if (!req.file.originalname.toLowerCase().match(/\.(xlsx|xls|csv)$/)) {
          return res.status(400).json({ error: "Unsupported file type. Please upload a spreadsheet." });
        }
        const buffer = await fs.promises.readFile(req.file.path);
        const workbook = xlsx.read(buffer, { type: "buffer", cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        data = xlsx.utils.sheet_to_json(worksheet, { header: 1 });
      } else {
        return res.status(400).json({ error: "No schedule file uploaded or text provided." });
      }

      if (!data || data.length < 2) {
        return res.status(400).json({ error: "Spreadsheet appears to be empty or has no data rows." });
      }

      // Automatically find headers
      const headersRow: any = data[0];
      const getHeaderIdx = (possibleNames: string[]) => {
          return headersRow.findIndex((h: any) => 
               h && typeof h === 'string' && possibleNames.some(p => h.toLowerCase().includes(p.toLowerCase()))
          );
      };

      const relDateIdx = getHeaderIdx(["general_release_date", "release date", "date", "general_release_date"]);
      const titleIdx = getHeaderIdx(["release_title", "title", "release name", "name"]);
      const artistIdx = getHeaderIdx(["release_artists", "artist", "creator"]);
      const catNoIdx = getHeaderIdx(["cat_no", "catalog number", "cat"]);
      const upcCodeIdx = getHeaderIdx(["upc_code", "upc"]);
      const labelIdx = getHeaderIdx(["label"]);
      const mainGenreIdx = getHeaderIdx(["main_genre", "genre"]);
      const subGenreIdx = getHeaderIdx(["sub_genre", "sub-genre"]);
      const spotifyIdx = getHeaderIdx(["spotify", "spotify_url"]);
      const instaIdx = getHeaderIdx(["instagram", "instagram_url", "ig"]);
      const listenIdx = getHeaderIdx(["listening link", "listen", "listening_url", "soundcloud"]);

      if (relDateIdx === -1) {
         return res.status(400).json({ error: "Could not find a 'Release Date' column in the spreadsheet headers." });
      }

      const events = [];
      const now = new Date();

      for (let i = 1; i < data.length; i++) {
         const row: any = data[i];
         if (!row || row.length === 0) continue;

         let rawDate = row[relDateIdx];
         if (!rawDate) continue;

         let releaseDate: Date;
         if (rawDate instanceof Date) {
             releaseDate = rawDate;
         } else if (typeof rawDate === "number") {
             // Excel date serial number (mac/windows)
             releaseDate = new Date((rawDate - 25569) * 86400 * 1000);
         } else {
             releaseDate = new Date(rawDate);
         }

         if (isNaN(releaseDate.getTime())) continue; // invalid date

         const artist = artistIdx !== -1 && row[artistIdx] ? String(row[artistIdx]) : "Unknown Artist";
         const title = titleIdx !== -1 && row[titleIdx] ? String(row[titleIdx]) : "Unknown Title";

         // Pitch deadline is 4 weeks before release date
         const pitchDeadline = new Date(releaseDate.getTime() - 4 * 7 * 24 * 60 * 60 * 1000);

         // De-duplicate if the same release appears multiple times (like in catalog_export where each row is a track)
         const exists = events.find(e => e.artist === artist && e.title === title);
         
         const isoDateStr = releaseDate.toISOString();
         if (exists) {
            if (exists.releaseDate !== isoDateStr) {
               if (!exists.alternativeDates) {
                  exists.alternativeDates = [];
               }
               if (!exists.alternativeDates.includes(isoDateStr)) {
                  exists.alternativeDates.push(isoDateStr);
               }
            }
            continue;
         }

         // Only add future pitches (or optionally can keep them all)
         events.push({
           artist,
           title,
           releaseDate: isoDateStr,
           pitchDeadline: pitchDeadline.toISOString(),
           catNo: catNoIdx !== -1 && row[catNoIdx] ? String(row[catNoIdx]) : "",
           upcCode: upcCodeIdx !== -1 && row[upcCodeIdx] ? String(row[upcCodeIdx]) : "",
           label: labelIdx !== -1 && row[labelIdx] ? String(row[labelIdx]) : "",
           mainGenre: mainGenreIdx !== -1 && row[mainGenreIdx] ? String(row[mainGenreIdx]) : "",
           subGenre: subGenreIdx !== -1 && row[subGenreIdx] ? String(row[subGenreIdx]) : "",
           spotifyUrl: spotifyIdx !== -1 && row[spotifyIdx] ? String(row[spotifyIdx]) : "",
           instagramUrl: instaIdx !== -1 && row[instaIdx] ? String(row[instaIdx]) : "",
           listeningUrl: listenIdx !== -1 && row[listenIdx] ? String(row[listenIdx]) : "",
         });
      }

      if (events.length === 0) {
        return res.status(400).json({ error: "No valid release dates were found in the schedule." });
      }

      events.sort((a, b) => new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime());

      res.json({ events });
    } catch (err: any) {
       console.error("Parse Schedule Error:", err);
       res.status(500).json({ error: "Failed to process the schedule." });
    }
  });

  // --- Submit Schedule Endpoint (Saves to Google Sheets) ---
  app.post("/api/submit-schedule", async (req, res) => {
    try {
      const { events, userEmail } = req.body;
      console.log("Submitting schedule with events:", JSON.stringify(events, null, 2));
      if (!events || !Array.isArray(events) || events.length === 0) {
        return res.status(400).json({ error: "No events provided." });
      }

      const sheets = getSheetsClient();
      const spreadsheetId = process.env.GOOGLE_SHEET_ID || "1-VLGEIvjkCPPQ4VE54FpC0mx7MuWqLrBpIbMpVk3owk";

      if (sheets && spreadsheetId) {
        const rowsToAppend = events.map((ev: any) => {
           const row = Array(32).fill("");
           row[0] = ev.catNo || "";
           row[1] = ev.upcCode || "";
           row[2] = new Date(ev.releaseDate).toLocaleDateString();
           row[3] = ev.label || "";
           row[4] = ev.title || "";
           row[5] = ev.artist || "";
           row[6] = ev.mainGenre || "";
           row[7] = ev.subGenre || "";
           row[8] = ev.spotifyUrl || "";
           row[9] = ev.instagramUrl || "";
           row[10] = ev.listeningUrl || "";
           row[11] = userEmail || "";
           
           // AF is index 31
           const hostLink = req.get('host') || req.headers.host || 'ais-pre-pro6iwtfl3rz7zi2fjrmca-302028590875.europe-west1.run.app';
           const protocol = req.headers['x-forwarded-proto'] || 'https';
           const lookupVal = ev.catNo || ev.upcCode || "";
           if (lookupVal) {
             row[31] = `=HYPERLINK("${protocol}://${hostLink}/?lookup=${lookupVal}", "Generate Press Release")`;
           }
           return row;
        });

        const targetTab = "Release Schedules";
        
        const requestPayload = {
          spreadsheetId,
          range: `'${targetTab}'!A:A`,
          valueInputOption: "USER_ENTERED",
          requestBody: {
            values: rowsToAppend,
          },
        };
        
        const tryAppend = () => sheets.spreadsheets.values.append(requestPayload);

        try {
          await tryAppend();
        } catch (appendErr: any) {
          if (appendErr.message && appendErr.message.includes("Unable to parse range")) {
            // Sheet might not exist, try creating it
            await sheets.spreadsheets.batchUpdate({
              spreadsheetId,
              requestBody: {
                requests: [{
                  addSheet: { properties: { title: targetTab } }
                }]
              }
            });
            
            // Add headers
            const headers = Array(32).fill("");
            headers[0] = "Catalog Number";
            headers[1] = "UPC";
            headers[2] = "Release Date";
            headers[3] = "Label";
            headers[4] = "Release Title";
            headers[5] = "Artist Name";
            headers[6] = "Main Genre";
            headers[7] = "Sub Genre";
            headers[8] = "Spotify URL";
            headers[9] = "Instagram URL";
            headers[10] = "Listening URL";
            headers[11] = "Submitted By";
            headers[31] = "Action";
            
            await sheets.spreadsheets.values.append({
              spreadsheetId,
              range: `'${targetTab}'!A1:AF1`,
              valueInputOption: "USER_ENTERED",
              requestBody: { values: [headers] }
            });
            
            // Try appending again
            await tryAppend();
          } else {
            throw appendErr;
          }
        }
      }
      
      const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;
      if (slackWebhookUrl) {
        try {
          const slackText = `📅 *New Release Schedule Submission*\n\n*Total Assets:* ${events.length}\n*Submitter:* ${userEmail || "Unknown"}\n\nCheck the connected Google Sheet for complete details.`;
          await fetch(slackWebhookUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: slackText }),
          });
        } catch (slackErr) {
          console.error("Failed to send Slack notification:", slackErr);
        }
      }

      res.json({ success: true });
    } catch (err: any) {
      console.error("Submit Schedule Error:", err);
      res.status(500).json({ error: "Failed to save schedule to Google Sheets.", details: err.message });
    }
  });

  // --- Schedule Template Download Endpoint ---
  app.get("/api/pitch/schedule-template", (req, res) => {
    try {
      const headers = [
        "CAT",
        "UPC",
        "Release Date",
        "Label",
        "Title",
        "Artist",
        "Genre",
        "Sub-Genre",
        "Spotify",
        "Instagram",
        "Listening Link"
      ];
      
      const wb = xlsx.utils.book_new();
      const ws = xlsx.utils.aoa_to_sheet([headers]);
      xlsx.utils.book_append_sheet(wb, ws, "Schedule");
      const buf = xlsx.write(wb, { type: "buffer", bookType: "csv" });
  
      res.setHeader('Content-Disposition', 'attachment; filename="catalog_export_template.csv"');
      res.setHeader('Content-Type', 'text/csv');
      res.send(buf);
    } catch (err: any) {
      console.error("Template Gen Error:", err);
      res.status(500).json({ error: "Failed to generate template." });
    }
  });

  // --- Vite middleware for the frontend ---
  if (process.env.NODE_ENV !== "production") {
    const isProxied = process.env.HMR_PROXY === "1";
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isProxied
          ? { server: httpServer, clientPort: 443, protocol: "wss" }
          : { server: httpServer }
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.use("/api/*", (req, res) => res.status(404).json({ error: "Not found" }));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // --- Global Error Handler ---
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err instanceof multer.MulterError) {
      const status = err.code === "LIMIT_FILE_SIZE" ? 413 : 400;
      return res.status(status).json({ error: err.message });
    }
    console.error("Unhandled Error:", err);
    if (!res.headersSent) {
      res.status(err.status || 500).json({ error: "An unexpected system error occurred. Please try again." });
    }
  });

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
