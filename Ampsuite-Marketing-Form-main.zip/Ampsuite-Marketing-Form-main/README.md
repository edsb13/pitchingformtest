# Artist Pitch Assistant

Client-facing form for artists and labels to upload release label-copy spreadsheets, link Spotify/Instagram URLs, and submit pitches for DSP campaigns. Submissions are written to a Google Sheet and notifications are sent via Resend.

**Live URL (production):** https://artist-pitch-assistant-332432500269.europe-west2.run.app/
Deployed on Google Cloud Run via AI Studio.

## Run locally

### Prerequisites
- Node.js 20+
- A `.env` file in the repo root with the variables listed in `.env.example`
- The Google service account in `GOOGLE_CLIENT_EMAIL` must have Editor access to both the target Sheet and the target Drive folder, or `/api/pitch` and `/api/upload` will fail.
- The domain in `RESEND_FROM` must be verified in Resend, or client confirmation emails will be silently rejected.

### Steps
1. `npm install`
2. Copy `.env.example` to `.env` and fill in values.
3. `npm run dev` — starts an Express server on port 3000 with Vite middleware for the React frontend.

## Deploy

Production deployments happen via AI Studio's Publish flow, which builds the app and pushes it to the existing Cloud Run service `artist-pitch-assistant` in `europe-west2`. Environment variables are configured on the Cloud Run revision.

## Endpoints
- `POST /api/extract` — accepts an array of `.xlsx` files under field `files`, returns deterministic-parser output per file
- `POST /api/upload` — uploads a single file to the configured Drive folder, returns a `webViewLink`
- `POST /api/pitch` — accepts a pitch payload (single object or array), appends rows to the Sheet, fires internal + submitter emails
